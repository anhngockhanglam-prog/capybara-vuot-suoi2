import { Play, Swords, Users } from 'lucide-react';
import { DIFFICULTY_LIST } from '../game/skins';
import { Difficulty, WeatherMode } from '../game/types';
import { WEATHER_OPTIONS } from '../game/weather';

interface TitleOverlayProps {
  difficulty: Difficulty;
  weatherMode: WeatherMode;
  highScore: number;
  onSelectDifficulty: (d: Difficulty) => void;
  onSelectWeather: (w: WeatherMode) => void;
  onStartEndless: () => void;
  onStartBossRush: () => void;
  onOpenMultiplayer: () => void;
}

export function TitleOverlay({
  difficulty,
  weatherMode,
  highScore,
  onSelectDifficulty,
  onSelectWeather,
  onStartEndless,
  onStartBossRush,
  onOpenMultiplayer,
}: TitleOverlayProps) {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-[#0D1712]/74 p-4 backdrop-blur-[2px]">
      <div className="w-full max-w-2xl rounded-xl border border-white/12 bg-[#16231D]/95 p-5 shadow-2xl sm:p-6">
        <div className="mb-1 text-xs font-medium text-amber-300/90">
          Trò chơi arcade 2D · Kỷ lục hiện tại:{' '}
          <span className="font-mono-num">{highScore.toLocaleString('vi-VN')}</span>
        </div>

        <h1 className="font-display text-balance text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
          Capybara Vượt Suối
        </h1>

        <p className="mt-1.5 text-sm leading-relaxed text-emerald-100/80">
          Vượt chướng ngại vật, tự do di chuyển đấu Boss bằng kỹ năng mua trong cửa hàng, hoặc tham gia máy chủ nhiều người chơi và tự tạo bản đồ.
        </p>

        {/* Difficulty Segmented Control */}
        <div className="mt-4">
          <div className="mb-1.5 text-xs font-medium text-emerald-200/80">Chọn nhịp độ</div>
          <div className="grid grid-cols-3 gap-1.5 rounded-lg bg-[#0F1814] p-1">
            {DIFFICULTY_LIST.map((item) => {
              const active = item.id === difficulty;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectDifficulty(item.id)}
                  className={`min-h-[40px] whitespace-nowrap rounded-md px-3 py-2 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 ${
                    active
                      ? 'bg-[#263C31] text-amber-300 shadow-sm'
                      : 'text-emerald-100/70 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Weather Segmented Control */}
        <div className="mt-3.5">
          <div className="mb-1.5 text-xs font-medium text-emerald-200/80">Hiệu ứng thời tiết</div>
          <div className="grid grid-cols-2 gap-1.5 rounded-lg bg-[#0F1814] p-1 sm:grid-cols-4">
            {WEATHER_OPTIONS.map((w) => {
              const active = w.id === weatherMode;
              return (
                <button
                  key={w.id}
                  type="button"
                  onClick={() => onSelectWeather(w.id)}
                  className={`min-h-[38px] whitespace-nowrap rounded-md px-2.5 py-1.5 text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 ${
                    active
                      ? 'bg-[#263C31] text-amber-300 shadow-sm'
                      : 'text-emerald-100/70 hover:text-white'
                  }`}
                >
                  {w.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Mode Action Buttons */}
        <div className="mt-5 flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onStartEndless}
            className="inline-flex h-11 items-center justify-center gap-2 whitespace-nowrap shrink-0 rounded-lg bg-amber-500 px-5 text-sm font-bold text-[#1A1308] transition-colors hover:bg-amber-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-300"
          >
            <Play className="h-4 w-4 fill-current" aria-hidden="true" />
            <span>Chạy Vượt Suối</span>
          </button>

          <button
            type="button"
            onClick={onStartBossRush}
            className="inline-flex h-11 items-center justify-center gap-2 whitespace-nowrap shrink-0 rounded-lg border border-rose-400/35 bg-rose-500/20 px-4 text-sm font-bold text-rose-200 transition-colors hover:bg-rose-500/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
          >
            <Swords className="h-4 w-4" aria-hidden="true" />
            <span>Đấu Boss Ngay</span>
          </button>

          <button
            type="button"
            onClick={onOpenMultiplayer}
            className="inline-flex h-11 items-center justify-center gap-2 whitespace-nowrap shrink-0 rounded-lg border border-emerald-400/35 bg-emerald-500/15 px-4 text-sm font-bold text-emerald-200 transition-colors hover:bg-emerald-500/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
          >
            <Users className="h-4 w-4" aria-hidden="true" />
            <span>Nhiều Người Chơi</span>
          </button>
        </div>
      </div>
    </div>
  );
}
