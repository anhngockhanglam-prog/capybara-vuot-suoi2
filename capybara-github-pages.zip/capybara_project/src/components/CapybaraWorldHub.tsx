import {
  Award,
  BatteryCharging,
  Camera,
  Carrot,
  Check,
  CloudRain,
  Compass,
  Crown,
  Download,
  Flame,
  Gamepad2,
  Heart,
  Home,
  Info,
  Lock,
  MapPin,
  Moon,
  PawPrint,
  Rainbow,
  Shirt,
  ShoppingBag,
  Shuffle,
  Smile,
  Snowflake,
  Sparkles,
  Sun,
  Swords,
  TrainFront,
  Trees,
  Trophy,
  Utensils,
  Waves,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import {
  ACHIEVEMENTS,
  countClaimableAchievements,
  getAchievementValue,
  isAchievementUnlocked,
} from '../game/achievements';
import { getPetDef, getPetEffectiveGoldenBonus, PET_OPTIONS } from '../game/pets';
import { BOSS_SKILLS } from '../game/skills';
import { FUR_OPTIONS, HEAD_ACCESSORIES, NECK_ACCESSORIES } from '../game/skins';
import { soundEngine } from '../game/sound';
import {
  AchievementStats,
  AchievementTier,
  ActiveWeather,
  CapybaraActivityId,
  CapybaraAppearance,
  CapybaraNeeds,
  CustomizationItem,
  FoodId,
  FurColorId,
  HeadAccessoryId,
  HomeItemId,
  NeckAccessoryId,
  PetId,
  SkillId,
  WorldAreaId,
  WorldLocationId,
} from '../game/types';
import {
  CAPYBARA_ACTIVITIES,
  EXPLORE_LOCATIONS,
  FOOD_ITEMS,
  HOME_ITEMS,
  hasWellFedBuff,
  WORLD_AREAS,
} from '../game/world';
import { CapybaraPreview } from './CapybaraPreview';
import { ScenePulseEvent, WorldSceneCanvas } from './WorldSceneCanvas';

type ShopTab = 'skills' | 'food' | 'outfit' | 'home_decor' | 'pets';
type WardrobeTab = 'fur' | 'head' | 'neck';

interface CapybaraWorldHubProps {
  yuzuBank: number;
  appearance: CapybaraAppearance;
  needs: CapybaraNeeds;
  foodInventory: Record<FoodId, number>;
  unlockedFur: FurColorId[];
  unlockedHead: HeadAccessoryId[];
  unlockedNeck: NeckAccessoryId[];
  unlockedSkills: SkillId[];
  unlockedHomeItems: HomeItemId[];
  activeHomeItems: HomeItemId[];
  unlockedPets: PetId[];
  selectedPet: PetId;
  petBond: Record<Exclude<PetId, 'none'>, number>;
  achievementStats: AchievementStats;
  claimedAchievements: string[];
  activeWeather: ActiveWeather;
  onChangeName: (name: string) => void;
  onSelectOrUnlockFur: (id: FurColorId) => void;
  onSelectOrUnlockHead: (id: HeadAccessoryId) => void;
  onSelectOrUnlockNeck: (id: NeckAccessoryId) => void;
  onRandomizeOutfit: () => void;
  onUnlockSkill: (id: SkillId) => void;
  onBuyFood: (id: FoodId) => void;
  onFeedCapybara: (id: FoodId) => void;
  onUnlockOrToggleHomeItem: (id: HomeItemId) => void;
  onSelectOrUnlockPet: (id: PetId) => void;
  onCarePet: (id: Exclude<PetId, 'none'>, action: 'pet' | 'treat') => { message: string; ok: boolean };
  onClaimAchievement: (id: string) => void;
  onOpenPhotoMode: () => void;
  onWorldActivity: (
    kind:
      | 'rest'
      | 'swim'
      | 'toss_yuzu'
      | 'forage'
      | 'meditate'
      | 'bounce'
      | 'pet'
      | 'playground_hit'
      | 'capy_activity',
    payload?: { golden?: boolean; activityId?: CapybaraActivityId }
  ) => { message: string; ok: boolean };
}

const AREA_ICONS: Record<WorldAreaId, typeof Home> = {
  home: Home,
  pool: Waves,
  forest: Trees,
  playground: Gamepad2,
  explore: MapPin,
  shop: ShoppingBag,
  wardrobe: Shirt,
  food: Carrot,
  pets: PawPrint,
  achievements: Trophy,
};

const TIER_STYLES: Record<
  AchievementTier,
  { label: string; frameClass: string; textClass: string }
> = {
  bronze: {
    label: 'Huy hiệu Đồng',
    frameClass: 'border-amber-700/60 bg-amber-900/35 text-amber-300',
    textClass: 'text-amber-300/90',
  },
  silver: {
    label: 'Huy hiệu Bạc',
    frameClass: 'border-slate-400/50 bg-slate-700/35 text-slate-200',
    textClass: 'text-slate-200',
  },
  gold: {
    label: 'Huy hiệu Vàng',
    frameClass: 'border-amber-400/60 bg-amber-500/20 text-amber-300',
    textClass: 'text-amber-300',
  },
  jade: {
    label: 'Huy hiệu Ngọc',
    frameClass: 'border-emerald-400/60 bg-emerald-500/20 text-emerald-300',
    textClass: 'text-emerald-300',
  },
};

function getAchievementIcon(id: string) {
  if (id.startsWith('boss_')) return Swords;
  if (id.startsWith('dist_') || id.startsWith('best_')) return Compass;
  if (id.startsWith('combo_')) return Crown;
  if (id.startsWith('fever_')) return Flame;
  if (id.startsWith('pet_')) return PawPrint;
  return Award;
}

export function CapybaraWorldHub({
  yuzuBank,
  appearance,
  needs,
  foodInventory,
  unlockedFur,
  unlockedHead,
  unlockedNeck,
  unlockedSkills,
  unlockedHomeItems,
  activeHomeItems,
  unlockedPets,
  selectedPet,
  petBond,
  achievementStats,
  claimedAchievements,
  activeWeather,
  onChangeName,
  onSelectOrUnlockFur,
  onSelectOrUnlockHead,
  onSelectOrUnlockNeck,
  onRandomizeOutfit,
  onUnlockSkill,
  onBuyFood,
  onFeedCapybara,
  onUnlockOrToggleHomeItem,
  onSelectOrUnlockPet,
  onCarePet,
  onClaimAchievement,
  onOpenPhotoMode,
  onWorldActivity,
}: CapybaraWorldHubProps) {
  const [area, setArea] = useState<WorldAreaId>('home');
  const [exploreLocation, setExploreLocation] = useState<
    Exclude<WorldLocationId, 'home' | 'pool' | 'forest' | 'playground'>
  >('city');
  const [sceneWeather, setSceneWeather] = useState<ActiveWeather>(activeWeather);
  const [starryNight, setStarryNight] = useState<boolean>(false);
  const [rainbowActive, setRainbowActive] = useState<boolean>(false);
  const [trainEnabled, setTrainEnabled] = useState<boolean>(true);
  const [lastSelfieUrl, setLastSelfieUrl] = useState<string | null>(null);
  const [shopTab, setShopTab] = useState<ShopTab>('skills');
  const [wardrobeTab, setWardrobeTab] = useState<WardrobeTab>('fur');
  const [hoveredSkillId, setHoveredSkillId] = useState<SkillId | null>(null);
  const [pinnedSkillId, setPinnedSkillId] = useState<SkillId | null>(null);
  const [pulseSeq, setPulseSeq] = useState(0);
  const [pulseEvent, setPulseEvent] = useState<ScenePulseEvent | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [playgroundTimeLeft, setPlaygroundTimeLeft] = useState(0);
  const [playgroundScore, setPlaygroundScore] = useState(0);

  const wellFed = hasWellFedBuff(needs);
  const activeMeta = WORLD_AREAS.find((w) => w.id === area) ?? WORLD_AREAS[0];
  const claimableCount = countClaimableAchievements(
    achievementStats,
    unlockedPets,
    claimedAchievements
  );

  const triggerPulse = (
    kind: ScenePulseEvent['kind'],
    label?: string,
    activityId?: CapybaraActivityId
  ) => {
    setPulseSeq((prev) => {
      const next = prev + 1;
      setPulseEvent({ seq: next, kind, label, activityId });
      return next;
    });
  };

  useEffect(() => {
    if (playgroundTimeLeft <= 0) return;
    const timer = window.setInterval(() => {
      setPlaygroundTimeLeft((t) => (t <= 1 ? 0 : t - 1));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [playgroundTimeLeft]);

  const handleAction = (
    action: 'rest' | 'swim' | 'toss_yuzu' | 'forage' | 'meditate' | 'bounce',
    pulseKind: ScenePulseEvent['kind']
  ) => {
    const res = onWorldActivity(action);
    setStatusMessage(res.message);
    if (res.ok) {
      triggerPulse(pulseKind, res.message);
    }
  };

  const handleCapyActivity = (
    activityId: CapybaraActivityId,
    switchLocation?: boolean
  ) => {
    const meta = CAPYBARA_ACTIVITIES.find((a) => a.id === activityId);
    if (!meta) return;
    if (switchLocation) {
      const loc = meta.recommendedLocation;
      if (loc === 'home' || loc === 'pool' || loc === 'forest' || loc === 'playground') {
        setArea(loc);
      } else {
        setArea('explore');
        setExploreLocation(loc);
      }
    }
    const res = onWorldActivity('capy_activity', { activityId });
    setStatusMessage(res.message);
    if (res.ok) {
      triggerPulse('activity', meta.shortLabel, activityId);
    }
  };

  const handleFeed = (foodId: FoodId) => {
    const item = FOOD_ITEMS.find((f) => f.id === foodId);
    if (!item || (foodInventory[foodId] ?? 0) <= 0) return;
    onFeedCapybara(foodId);
    const msg = `Đã cho ăn ${item.name} (+${item.hungerGain}% No)`;
    setStatusMessage(msg);
    triggerPulse('feed', `+${item.hungerGain}% No!`);
  };

  const startPlaygroundGame = () => {
    setPlaygroundScore(0);
    setPlaygroundTimeLeft(15);
    setStatusMessage('Bấm nhanh vào các trái quýt đang nảy trên sân chơi trong 15 giây!');
    triggerPulse('minigame_start');
  };

  const renderStatBar = (
    label: string,
    value: number,
    barColor: string,
    IconComponent: typeof Utensils
  ) => (
    <div className="min-w-0 flex-1">
      <div className="flex items-center justify-between text-xs">
        <span className="flex items-center gap-1.5 font-medium text-emerald-100/85">
          <IconComponent className="h-3.5 w-3.5 text-amber-300" aria-hidden="true" />
          <span>{label}</span>
        </span>
        <span className="font-mono-num font-bold text-white">{value}%</span>
      </div>
      <div className="mt-1.5 h-2 w-full overflow-hidden rounded-sm bg-[#0D1612]">
        <div
          className="h-full transition-all duration-200"
          style={{ width: `${value}%`, backgroundColor: barColor }}
        />
      </div>
    </div>
  );

  const renderOutfitCards = <T extends string>(
    items: CustomizationItem<T>[],
    unlocked: T[],
    selected: T,
    onAction: (id: T) => void,
    ownedOnly: boolean
  ) => {
    const list = ownedOnly ? items.filter((item) => unlocked.includes(item.id)) : items;
    return (
      <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
        {list.map((item) => {
          const isUnlocked = unlocked.includes(item.id);
          const isSelected = selected === item.id;
          const canAfford = yuzuBank >= item.cost;

          return (
            <div
              key={item.id}
              className={`flex flex-col justify-between rounded-xl border p-3.5 transition-colors ${
                isSelected
                  ? 'border-amber-400/60 bg-[#1D2E26]'
                  : 'border-white/10 bg-[#14201A]'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-2">
                    <span
                      className="h-4 w-4 shrink-0 rounded-sm border border-white/20"
                      style={{ backgroundColor: item.swatchColor }}
                      aria-hidden="true"
                    />
                    <span className="font-display text-sm font-bold text-white">
                      {item.name}
                    </span>
                  </span>
                  <span className="font-mono-num text-xs text-emerald-200/75">
                    {isUnlocked ? 'Đã mở' : `${item.cost} quýt`}
                  </span>
                </div>
                <p className="mt-1.5 text-xs leading-relaxed text-emerald-100/70">
                  {item.description}
                </p>
              </div>

              <div className="mt-3">
                <button
                  type="button"
                  disabled={!isUnlocked && !canAfford}
                  onClick={() => onAction(item.id)}
                  className={`inline-flex h-10 w-full items-center justify-center gap-1.5 whitespace-nowrap rounded-lg px-3 text-xs font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 ${
                    isSelected
                      ? 'border border-emerald-400/40 bg-emerald-500/20 text-emerald-300'
                      : isUnlocked
                      ? 'bg-[#23372E] text-white hover:bg-[#2E473C]'
                      : canAfford
                      ? 'bg-amber-500 text-[#1A1308] hover:bg-amber-400'
                      : 'cursor-not-allowed bg-white/5 text-white/35'
                  }`}
                >
                  {isSelected ? (
                    <>
                      <Check className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Đang mặc</span>
                    </>
                  ) : isUnlocked ? (
                    <span>Mặc ngay</span>
                  ) : canAfford ? (
                    <span>Mua ({item.cost} quýt)</span>
                  ) : (
                    <>
                      <Lock className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Cần {item.cost} quýt</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const quickFoods = FOOD_ITEMS.filter((f) => (foodInventory[f.id] ?? 0) > 0);

  return (
    <section
      aria-labelledby="world-hub-heading"
      className="flex flex-col rounded-2xl border border-white/10 bg-[#16231D] p-5"
    >
      {/* Top World Header + Care Status Bars */}
      <div className="flex flex-wrap items-start justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <h2 id="world-hub-heading" className="font-display text-lg font-bold text-white">
            Thế giới Capybara · {appearance.name || 'Mochi'}
          </h2>
          <p className="mt-0.5 text-xs text-emerald-100/70">
            {wellFed
              ? 'Trạng thái Sung Sức: Bắt đầu lượt chạy mới với 4 Tim tối đa (+1 Tim).'
              : 'Chăm sóc Độ no ≥ 70% và Niềm vui ≥ 60% để nhận +1 Tim khi bắt đầu lượt chạy.'}
          </p>
        </div>

        <div className="flex items-center gap-4 text-sm text-emerald-100/90">
          <div>
            <span>Kho quýt: </span>
            <span className="font-mono-num font-bold text-amber-400">{yuzuBank} quả</span>
          </div>
        </div>
      </div>

      {/* Capybara Needs Bar */}
      <div className="mt-4 grid grid-cols-1 gap-3 rounded-xl border border-white/10 bg-[#14201A] p-3.5 sm:grid-cols-3">
        {renderStatBar('Độ no', needs.hunger, '#F97316', Utensils)}
        {renderStatBar('Năng lượng', needs.energy, '#38BDF8', BatteryCharging)}
        {renderStatBar('Niềm vui', needs.happiness, '#10B981', Smile)}
      </div>

      {/* 9 Location Tabs */}
      <nav
        aria-label="Khu vực thế giới Capybara"
        className="mt-4 grid grid-cols-3 gap-1.5 rounded-xl bg-[#0F1814] p-1.5 sm:grid-cols-5"
      >
        {WORLD_AREAS.map((item) => {
          const Icon = AREA_ICONS[item.id];
          const active = area === item.id;
          const label =
            item.id === 'achievements' && claimableCount > 0
              ? `${item.label} (${claimableCount})`
              : item.label;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setArea(item.id);
                setStatusMessage(null);
              }}
              className={`inline-flex h-10 items-center justify-center gap-1.5 whitespace-nowrap shrink-0 rounded-lg px-2.5 text-xs font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 ${
                active
                  ? 'bg-[#263C31] text-amber-300 shadow-sm'
                  : item.id === 'achievements' && claimableCount > 0
                  ? 'text-amber-300 hover:bg-[#182620]'
                  : 'text-emerald-100/75 hover:bg-[#182620] hover:text-white'
              }`}
            >
              <Icon className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
              <span>{label}</span>
            </button>
          );
        })}
      </nav>

      {/* Active Area Subtitle + Action Feedback */}
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs">
        <span className="text-emerald-200/80">
          <strong className="text-white">{activeMeta.label}:</strong> {activeMeta.subtitle}
        </span>
        {statusMessage && (
          <span className="font-medium text-amber-300">{statusMessage}</span>
        )}
      </div>

      {/* Interactive Areas: Home, Pool, Forest, Playground, Explore World */}
      {(area === 'home' ||
        area === 'pool' ||
        area === 'forest' ||
        area === 'playground' ||
        area === 'explore') && (
        <div className="mt-3 grid grid-cols-1 gap-4 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <WorldSceneCanvas
              area={area === 'explore' ? exploreLocation : area}
              appearance={appearance}
              petId={selectedPet}
              weather={sceneWeather}
              starryNight={starryNight}
              rainbowActive={rainbowActive}
              trainEnabled={trainEnabled}
              activeHomeItems={activeHomeItems}
              pulseEvent={pulseEvent}
              playgroundGameActive={area === 'playground' && playgroundTimeLeft > 0}
              onScenePet={() => {
                const res = onWorldActivity('pet');
                setStatusMessage(res.message);
              }}
              onSelfieReady={(url) => setLastSelfieUrl(url)}
              onPlaygroundTargetHit={(isGolden) => {
                setPlaygroundScore((s) => s + (isGolden ? 3 : 1));
                const res = onWorldActivity('playground_hit', { golden: isGolden });
                setStatusMessage(res.message);
              }}
            />

            {/* Scene Atmosphere & Railway Controls */}
            <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() => {
                  const wasRaining = sceneWeather === 'rain';
                  setSceneWeather('clear');
                  if (wasRaining) {
                    setRainbowActive(true);
                    setStatusMessage('Tạnh mưa rồi! Cầu vồng bảy sắc đã xuất hiện!');
                  }
                }}
                className={`inline-flex h-8 items-center gap-1 whitespace-nowrap rounded-md border px-2.5 text-[11px] font-semibold transition-colors ${
                  sceneWeather === 'clear'
                    ? 'border-amber-400/50 bg-amber-500/20 text-amber-200'
                    : 'border-white/10 bg-[#0F1814] text-emerald-100/75 hover:text-white'
                }`}
              >
                <Sun className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Nắng nhẹ</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSceneWeather('rain');
                  setRainbowActive(false);
                }}
                className={`inline-flex h-8 items-center gap-1 whitespace-nowrap rounded-md border px-2.5 text-[11px] font-semibold transition-colors ${
                  sceneWeather === 'rain'
                    ? 'border-sky-400/50 bg-sky-500/20 text-sky-200'
                    : 'border-white/10 bg-[#0F1814] text-emerald-100/75 hover:text-white'
                }`}
              >
                <CloudRain className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Mưa & vũng nước</span>
              </button>

              <button
                type="button"
                onClick={() => setSceneWeather('snow')}
                className={`inline-flex h-8 items-center gap-1 whitespace-nowrap rounded-md border px-2.5 text-[11px] font-semibold transition-colors ${
                  sceneWeather === 'snow'
                    ? 'border-cyan-300/50 bg-cyan-500/20 text-cyan-100'
                    : 'border-white/10 bg-[#0F1814] text-emerald-100/75 hover:text-white'
                }`}
              >
                <Snowflake className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Mùa đông tuyết</span>
              </button>

              <button
                type="button"
                onClick={() => setRainbowActive((v) => !v)}
                className={`inline-flex h-8 items-center gap-1 whitespace-nowrap rounded-md border px-2.5 text-[11px] font-semibold transition-colors ${
                  rainbowActive
                    ? 'border-pink-400/50 bg-pink-500/20 text-pink-200'
                    : 'border-white/10 bg-[#0F1814] text-emerald-100/75 hover:text-white'
                }`}
              >
                <Rainbow className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Cầu vồng</span>
              </button>

              <button
                type="button"
                onClick={() => setStarryNight((v) => !v)}
                className={`inline-flex h-8 items-center gap-1 whitespace-nowrap rounded-md border px-2.5 text-[11px] font-semibold transition-colors ${
                  starryNight
                    ? 'border-indigo-400/50 bg-indigo-500/25 text-indigo-200'
                    : 'border-white/10 bg-[#0F1814] text-emerald-100/75 hover:text-white'
                }`}
              >
                <Moon className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Bầu trời sao</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setTrainEnabled((v) => {
                    const next = !v;
                    if (next) soundEngine.playTrainWhistle();
                    return next;
                  });
                }}
                className={`inline-flex h-8 items-center gap-1 whitespace-nowrap rounded-md border px-2.5 text-[11px] font-semibold transition-colors ${
                  trainEnabled
                    ? 'border-emerald-400/50 bg-emerald-500/20 text-emerald-200'
                    : 'border-white/10 bg-[#0F1814] text-emerald-100/75 hover:text-white'
                }`}
              >
                <TrainFront className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Tàu chạy bản đồ</span>
              </button>
            </div>

            {lastSelfieUrl && (
              <div className="mt-2 flex items-center justify-between gap-2 rounded-lg border border-amber-400/35 bg-[#121D18] px-3 py-2 text-xs">
                <span className="text-amber-200">Ảnh Selfie vừa chụp đã sẵn sàng!</span>
                <a
                  href={lastSelfieUrl}
                  download={`capybara-selfie-${Date.now()}.png`}
                  className="inline-flex h-8 items-center gap-1.5 whitespace-nowrap rounded-md bg-amber-500 px-3 text-xs font-bold text-[#1A1308] hover:bg-amber-400"
                >
                  <Download className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Lưu ảnh Selfie</span>
                </a>
              </div>
            )}

            <p className="mt-2 text-[11px] text-emerald-200/65">
              Mẹo: Chạm vào Capybara để vuốt ve, chọn Bầu trời sao / Mưa sang Nắng để ngắm cầu vồng, hoặc bấm các hoạt động bên cạnh.
            </p>
          </div>

          <div className="flex flex-col justify-between gap-3 rounded-xl border border-white/10 bg-[#14201A] p-4 lg:col-span-5">
            {area === 'home' && (
              <div className="space-y-2.5">
                <div className="font-display text-sm font-bold text-white">Hoạt động tại Nhà riêng</div>
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  <button
                    type="button"
                    onClick={() => handleCapyActivity('nap_snore')}
                    className="inline-flex h-10 items-center justify-center whitespace-nowrap rounded-lg bg-amber-500 px-3 text-xs font-bold text-[#1A1308] hover:bg-amber-400"
                  >
                    Ngủ & ngáy (+35% NL)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleCapyActivity('sleep_teddy')}
                    className="inline-flex h-10 items-center justify-center whitespace-nowrap rounded-lg border border-amber-400/40 bg-amber-500/15 px-3 text-xs font-bold text-amber-200 hover:bg-amber-500/25"
                  >
                    Ôm gấu bông ngủ (+42% NL)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleCapyActivity('arcade_game')}
                    className="inline-flex h-10 items-center justify-center whitespace-nowrap rounded-lg border border-emerald-400/40 bg-emerald-500/15 px-3 text-xs font-bold text-emerald-200 hover:bg-emerald-500/25 sm:col-span-2"
                  >
                    Chơi máy điện tử (+25% Vui & +2 Quýt)
                  </button>
                </div>

                <div className="border-t border-white/10 pt-3">
                  <div className="flex items-center justify-between text-xs font-semibold text-emerald-200/85">
                    <span>Bài trí nội thất đã mở</span>
                    <button
                      type="button"
                      onClick={() => {
                        setArea('shop');
                        setShopTab('home_decor');
                      }}
                      className="text-amber-300 hover:underline"
                    >
                      Mua thêm ở Cửa hàng
                    </button>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {HOME_ITEMS.filter((item) => unlockedHomeItems.includes(item.id)).map((item) => {
                      const active = activeHomeItems.includes(item.id);
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => onUnlockOrToggleHomeItem(item.id)}
                          className={`h-9 whitespace-nowrap rounded-md border px-2.5 text-xs font-medium transition-colors ${
                            active
                              ? 'border-emerald-400/50 bg-emerald-500/20 text-emerald-200'
                              : 'border-white/15 bg-[#0F1814] text-emerald-100/70 hover:text-white'
                          }`}
                        >
                          {active ? `Đang đặt: ${item.name}` : `Đặt ${item.name}`}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {area === 'pool' && (
              <div className="space-y-2.5">
                <div className="font-display text-sm font-bold text-white">Thư giãn tại Hồ bơi</div>
                <button
                  type="button"
                  onClick={() => handleCapyActivity('bubble_bath')}
                  className="inline-flex h-10 w-full items-center justify-center gap-2 whitespace-nowrap rounded-lg bg-cyan-400 px-4 text-xs font-bold text-[#08202C] hover:bg-cyan-300"
                >
                  <span>Tắm bồn bong bóng xà phòng (+24% Vui, +18% NL)</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleCapyActivity('dive_swim')}
                  className="inline-flex h-10 w-full items-center justify-center gap-2 whitespace-nowrap rounded-lg bg-sky-500 px-4 text-xs font-bold text-[#08202C] hover:bg-sky-400"
                >
                  <span>Bơi và lặn dưới nước (+22% Vui & +2 Quýt)</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleAction('toss_yuzu', 'toss_yuzu')}
                  className="inline-flex h-10 w-full items-center justify-center gap-2 whitespace-nowrap rounded-lg border border-amber-400/40 bg-amber-500/15 px-4 text-xs font-bold text-amber-200 hover:bg-amber-500/25"
                >
                  <span>Thả quýt xuống hồ (+Vui vẻ & có cơ hội nhặt quýt)</span>
                </button>
              </div>
            )}

            {area === 'forest' && (
              <div className="space-y-2.5">
                <div className="font-display text-sm font-bold text-white">Khám phá Khu rừng</div>
                <button
                  type="button"
                  disabled={needs.energy < 15}
                  onClick={() => handleAction('forage', 'forage')}
                  className="inline-flex h-10 w-full items-center justify-center gap-2 whitespace-nowrap rounded-lg bg-emerald-500 px-4 text-xs font-bold text-[#082216] hover:bg-emerald-400 disabled:cursor-not-allowed disabled:opacity-45"
                >
                  <span>Đi hái quýt & tìm thức ăn (-15% Năng lượng)</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleAction('meditate', 'meditate')}
                  className="inline-flex h-10 w-full items-center justify-center gap-2 whitespace-nowrap rounded-lg border border-white/15 bg-[#1D2E26] px-4 text-xs font-semibold text-white hover:bg-[#273E33]"
                >
                  <span>Thiền dưới tán tre (+18% Năng lượng, +12% Vui)</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleCapyActivity('eat_watermelon')}
                  className="inline-flex h-10 w-full items-center justify-center gap-2 whitespace-nowrap rounded-lg border border-rose-400/40 bg-rose-500/15 px-4 text-xs font-bold text-rose-200 hover:bg-rose-500/25"
                >
                  <span>Ăn dưa hấu mát lạnh (+28% No, +18% Vui)</span>
                </button>
              </div>
            )}

            {area === 'playground' && (
              <div className="space-y-2.5">
                <div className="font-display text-sm font-bold text-white">Hoạt động Khu vui chơi</div>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleCapyActivity('dance')}
                    className="inline-flex h-9 items-center justify-center whitespace-nowrap rounded-lg bg-purple-500 px-2.5 text-xs font-bold text-white hover:bg-purple-400"
                  >
                    Nhảy theo nhạc
                  </button>
                  <button
                    type="button"
                    onClick={() => handleCapyActivity('balloon')}
                    className="inline-flex h-9 items-center justify-center whitespace-nowrap rounded-lg bg-pink-500 px-2.5 text-xs font-bold text-white hover:bg-pink-400"
                  >
                    Chơi bóng bay
                  </button>
                  <button
                    type="button"
                    onClick={() => handleCapyActivity('selfie')}
                    className="inline-flex h-9 items-center justify-center whitespace-nowrap rounded-lg border border-amber-400/40 bg-amber-500/15 px-2.5 text-xs font-bold text-amber-200 hover:bg-amber-500/25"
                  >
                    Chụp selfie
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAction('bounce', 'bounce')}
                    className="inline-flex h-9 items-center justify-center whitespace-nowrap rounded-lg border border-white/15 bg-[#1D2E26] px-2.5 text-xs font-semibold text-white hover:bg-[#273E33]"
                  >
                    Nhảy bạt nhún
                  </button>
                </div>

                <div className="rounded-lg border border-white/10 bg-[#0F1814] p-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-amber-300">Mini-game: Bắt Quýt Nảy</span>
                    <span className="font-mono-num text-emerald-200">
                      {playgroundTimeLeft > 0
                        ? `Còn ${playgroundTimeLeft}s · +${playgroundScore} quýt`
                        : '15 giây'}
                    </span>
                  </div>
                  <button
                    type="button"
                    disabled={playgroundTimeLeft > 0}
                    onClick={startPlaygroundGame}
                    className="mt-2 inline-flex h-9 w-full items-center justify-center whitespace-nowrap rounded-md bg-amber-500 px-3 text-xs font-bold text-[#1A1308] hover:bg-amber-400 disabled:opacity-50"
                  >
                    {playgroundTimeLeft > 0 ? 'Đang chơi — Bấm quýt trên sân!' : 'Chơi bắt quýt ngay'}
                  </button>
                </div>
              </div>
            )}

            {area === 'explore' && (
              <div className="space-y-3">
                <div>
                  <div className="font-display text-sm font-bold text-white">
                    Điểm đến Bản đồ Thế giới (7 vùng mới)
                  </div>
                  <div className="mt-2 grid grid-cols-2 gap-1.5">
                    {EXPLORE_LOCATIONS.map((loc) => {
                      const active = exploreLocation === loc.id;
                      return (
                        <button
                          key={loc.id}
                          type="button"
                          onClick={() => {
                            setExploreLocation(loc.id);
                            setStatusMessage(`${loc.label}: ${loc.subtitle}`);
                            if (loc.id === 'winter') setSceneWeather('snow');
                          }}
                          className={`inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-lg border px-2.5 text-xs font-semibold transition-colors ${
                            active
                              ? 'border-amber-400/60 bg-[#23372E] text-amber-300'
                              : 'border-white/10 bg-[#0F1814] text-emerald-100/80 hover:text-white'
                          }`}
                        >
                          <span
                            className="h-2.5 w-2.5 shrink-0 rounded-sm"
                            style={{ backgroundColor: loc.accentColor }}
                            aria-hidden="true"
                          />
                          <span className="truncate">{loc.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="border-t border-white/10 pt-2.5">
                  <div className="font-display text-xs font-bold text-emerald-200">
                    10 Hoạt động Capybara tại chỗ
                  </div>
                  <div className="mt-2 grid grid-cols-2 gap-1.5">
                    {CAPYBARA_ACTIVITIES.map((act) => (
                      <button
                        key={act.id}
                        type="button"
                        onClick={() => handleCapyActivity(act.id)}
                        title={act.description}
                        className="inline-flex h-8 items-center gap-1.5 whitespace-nowrap rounded-md border border-white/12 bg-[#0F1814] px-2 text-[11px] font-medium text-white transition-colors hover:border-amber-400/50 hover:text-amber-200"
                      >
                        <span
                          className="h-2 w-2 shrink-0 rounded-sm"
                          style={{ backgroundColor: act.accentColor }}
                          aria-hidden="true"
                        />
                        <span className="truncate">{act.shortLabel}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Quick Feed Snack Bar available inside interactive zones */}
            <div className="border-t border-white/10 pt-3">
              <div className="flex items-center justify-between text-xs font-semibold text-emerald-200/85">
                <span>Cho ăn nhanh</span>
                <button
                  type="button"
                  onClick={() => setArea('food')}
                  className="text-amber-300 hover:underline"
                >
                  Mở kho thức ăn
                </button>
              </div>
              {quickFoods.length === 0 ? (
                <p className="mt-1.5 text-xs text-emerald-100/60">
                  Kho thức ăn đang trống. Ghé Cửa hàng hoặc Khu rừng để kiếm thêm.
                </p>
              ) : (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {quickFoods.slice(0, 3).map((food) => (
                    <button
                      key={food.id}
                      type="button"
                      onClick={() => handleFeed(food.id)}
                      className="inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-md border border-white/15 bg-[#0F1814] px-2.5 text-xs font-medium text-white hover:border-amber-400/50"
                    >
                      <span>{food.name}</span>
                      <span className="font-mono-num text-amber-300">x{foodInventory[food.id]}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Wardrobe Area */}
      {area === 'wardrobe' && (
        <div className="mt-4 space-y-4">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            <CapybaraPreview
              appearance={appearance}
              weather={activeWeather}
              petId={selectedPet}
            />
            <div className="flex-1 space-y-3">
              <div className="flex flex-wrap items-end gap-2">
                <div className="min-w-[180px] flex-1">
                  <label
                    htmlFor="capybara-name-input"
                    className="block text-xs font-medium text-emerald-200/80"
                  >
                    Tên chú Capybara
                  </label>
                  <input
                    id="capybara-name-input"
                    type="text"
                    maxLength={16}
                    value={appearance.name}
                    onChange={(e) => onChangeName(e.target.value)}
                    placeholder="Nhập tên (vd: Mochi)"
                    className="mt-1.5 h-10 w-full rounded-lg border border-white/15 bg-[#0F1814] px-3 text-sm font-medium text-white placeholder:text-white/35 focus:border-amber-400 focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                </div>
                <button
                  type="button"
                  onClick={onRandomizeOutfit}
                  className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-lg border border-white/15 bg-[#21332A] px-3.5 text-xs font-semibold text-white hover:bg-[#2C4438]"
                >
                  <Shuffle className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Phối ngẫu nhiên</span>
                </button>
                <button
                  type="button"
                  onClick={onOpenPhotoMode}
                  className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-lg bg-amber-500 px-3.5 text-xs font-bold text-[#1A1308] hover:bg-amber-400"
                >
                  <Camera className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Chụp ảnh ngay</span>
                </button>
              </div>

              <div className="grid grid-cols-3 gap-1.5 rounded-lg bg-[#0F1814] p-1">
                {(
                  [
                    { id: 'fur', label: 'Màu lông' },
                    { id: 'head', label: 'Phụ kiện đầu' },
                    { id: 'neck', label: 'Phụ kiện cổ' },
                  ] as const
                ).map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setWardrobeTab(t.id)}
                    className={`h-9 whitespace-nowrap rounded-md px-2 text-xs font-semibold transition-colors ${
                      wardrobeTab === t.id
                        ? 'bg-[#263C31] text-amber-300'
                        : 'text-emerald-100/70 hover:text-white'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {wardrobeTab === 'fur' &&
            renderOutfitCards(FUR_OPTIONS, unlockedFur, appearance.fur, onSelectOrUnlockFur, true)}
          {wardrobeTab === 'head' &&
            renderOutfitCards(
              HEAD_ACCESSORIES,
              unlockedHead,
              appearance.head,
              onSelectOrUnlockHead,
              true
            )}
          {wardrobeTab === 'neck' &&
            renderOutfitCards(
              NECK_ACCESSORIES,
              unlockedNeck,
              appearance.neck,
              onSelectOrUnlockNeck,
              true
            )}

          <div className="flex items-center justify-between rounded-xl border border-white/10 bg-[#14201A] px-4 py-3 text-xs text-emerald-100/80">
            <span>Muốn mở khóa thêm màu lông và phụ kiện mới?</span>
            <button
              type="button"
              onClick={() => {
                setArea('shop');
                setShopTab('outfit');
              }}
              className="font-bold text-amber-300 hover:underline"
            >
              Mở Cửa hàng Trang phục
            </button>
          </div>
        </div>
      )}

      {/* Food System Area */}
      {area === 'food' && (
        <div className="mt-4 space-y-4">
          <div className="flex flex-col gap-4 rounded-xl border border-white/10 bg-[#14201A] p-4 sm:flex-row sm:items-center">
            <CapybaraPreview
              appearance={appearance}
              weather={activeWeather}
              petId={selectedPet}
            />
            <div className="flex-1 space-y-2">
              <div className="font-display text-base font-bold text-white">
                Hệ thống Thức ăn & Dinh dưỡng
              </div>
              <p className="text-xs leading-relaxed text-emerald-100/75">
                Cho Capybara ăn từ kho đồ ăn để hồi Độ no, Năng lượng và Niềm vui. Khi Độ no đạt từ
                70% và Niềm vui từ 60% trở lên, Capybara sẽ có thêm 1 Tim tối đa khi bắt đầu chạy.
              </p>
              <button
                type="button"
                onClick={() => {
                  setArea('shop');
                  setShopTab('food');
                }}
                className="inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-lg bg-amber-500 px-3.5 text-xs font-bold text-[#1A1308] hover:bg-amber-400"
              >
                <ShoppingBag className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Mua thêm thức ăn</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {FOOD_ITEMS.map((food) => {
              const count = foodInventory[food.id] ?? 0;
              return (
                <div
                  key={food.id}
                  className="flex flex-col justify-between rounded-xl border border-white/10 bg-[#14201A] p-3.5"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="flex items-center gap-2">
                        <span
                          className="h-3.5 w-3.5 shrink-0 rounded-sm border border-white/20"
                          style={{ backgroundColor: food.accentColor }}
                          aria-hidden="true"
                        />
                        <span className="font-display text-sm font-bold text-white">
                          {food.name}
                        </span>
                      </span>
                      <span className="font-mono-num text-xs font-bold text-amber-300">
                        Còn: {count} phần
                      </span>
                    </div>
                    <p className="mt-1.5 text-xs leading-relaxed text-emerald-100/75">
                      {food.description}
                    </p>
                    <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-emerald-200/80">
                      <span>+{food.hungerGain}% No</span>
                      <span>·</span>
                      <span>+{food.energyGain}% Năng lượng</span>
                      <span>·</span>
                      <span>+{food.happinessGain}% Vui</span>
                    </div>
                  </div>

                  <div className="mt-3 flex gap-2">
                    <button
                      type="button"
                      disabled={count <= 0}
                      onClick={() => handleFeed(food.id)}
                      className="inline-flex h-10 flex-1 items-center justify-center whitespace-nowrap rounded-lg bg-emerald-500 px-3 text-xs font-bold text-[#082216] hover:bg-emerald-400 disabled:cursor-not-allowed disabled:bg-white/5 disabled:text-white/35"
                    >
                      {count > 0 ? 'Cho Capybara ăn' : 'Hết món'}
                    </button>
                    <button
                      type="button"
                      disabled={yuzuBank < food.cost}
                      onClick={() => onBuyFood(food.id)}
                      className="inline-flex h-10 items-center justify-center whitespace-nowrap rounded-lg border border-amber-400/40 bg-amber-500/15 px-3 text-xs font-bold text-amber-200 hover:bg-amber-500/25 disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      Mua ({food.cost} quýt)
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Small Pet Companions Area */}
      {area === 'pets' && (
        <div className="mt-4 space-y-4">
          <div className="flex flex-col gap-4 rounded-xl border border-white/10 bg-[#14201A] p-4 sm:flex-row sm:items-center">
            <CapybaraPreview
              appearance={appearance}
              weather={activeWeather}
              petId={selectedPet}
            />
            <div className="flex-1 space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="font-display text-base font-bold text-white">
                  Thú cưng đồng hành ·{' '}
                  <span className="text-amber-300">{getPetDef(selectedPet).name}</span>
                </div>
                {selectedPet !== 'none' && (
                  <span className="font-mono-num text-xs font-semibold text-emerald-300">
                    +{Math.round(getPetEffectiveGoldenBonus(selectedPet, petBond[selectedPet]) * 100)}% Quýt Vàng (Endless)
                  </span>
                )}
              </div>
              <p className="text-xs leading-relaxed text-emerald-100/75">
                Nhận nuôi và chăm sóc thú cưng nhỏ đi theo sau Capybara trên mọi cung đường. Khi độ
                Thân thiết đạt từ 45% và 70%, thú cưng còn tăng thêm tỉ lệ rơi Quýt Vàng trong chế
                độ Endless.
              </p>

              {selectedPet !== 'none' && (
                <div className="mt-2 flex flex-wrap items-center gap-2 pt-1">
                  <div className="min-w-[140px] flex-1">
                    <div className="flex items-center justify-between text-[11px] text-emerald-100/85">
                      <span className="flex items-center gap-1">
                        <Heart className="h-3 w-3 text-rose-400" aria-hidden="true" />
                        <span>Độ thân thiết</span>
                      </span>
                      <span className="font-mono-num font-bold text-white">
                        {petBond[selectedPet]}%
                      </span>
                    </div>
                    <div className="mt-1 h-1.5 w-full overflow-hidden rounded-sm bg-[#0D1612]">
                      <div
                        className="h-full bg-rose-400 transition-all duration-200"
                        style={{ width: `${petBond[selectedPet]}%` }}
                      />
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const res = onCarePet(selectedPet, 'pet');
                      setStatusMessage(res.message);
                    }}
                    className="inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-lg border border-white/15 bg-[#21332A] px-3 text-xs font-semibold text-white hover:bg-[#2B4337]"
                  >
                    <Sparkles className="h-3.5 w-3.5 text-amber-300" aria-hidden="true" />
                    <span>Vuốt ve (+8%)</span>
                  </button>
                  <button
                    type="button"
                    disabled={yuzuBank < 3}
                    onClick={() => {
                      const res = onCarePet(selectedPet, 'treat');
                      setStatusMessage(res.message);
                    }}
                    className="inline-flex h-9 items-center gap-1.5 whitespace-nowrap rounded-lg bg-amber-500 px-3 text-xs font-bold text-[#1A1308] hover:bg-amber-400 disabled:cursor-not-allowed disabled:opacity-45"
                  >
                    <span>Cho ăn vặt (3 quýt, +18%)</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {PET_OPTIONS.map((pet) => {
              const isUnlocked = unlockedPets.includes(pet.id);
              const isSelected = selectedPet === pet.id;
              const canAfford = yuzuBank >= pet.cost;
              const bond = pet.id !== 'none' ? petBond[pet.id] : 0;

              return (
                <div
                  key={pet.id}
                  className={`flex flex-col justify-between rounded-xl border p-3.5 transition-colors ${
                    isSelected
                      ? 'border-amber-400/60 bg-[#1D2E26]'
                      : 'border-white/10 bg-[#14201A]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="flex items-center gap-2">
                        <span
                          className="h-4 w-4 shrink-0 rounded-sm border border-white/20"
                          style={{ backgroundColor: pet.accentColor }}
                          aria-hidden="true"
                        />
                        <span className="font-display text-sm font-bold text-white">
                          {pet.name}
                        </span>
                      </span>
                      <span className="font-mono-num text-xs text-emerald-200/80">
                        {isUnlocked ? 'Đã nhận nuôi' : `${pet.cost} quýt`}
                      </span>
                    </div>
                    <div className="mt-1 text-[11px] font-medium text-amber-300/85">
                      {pet.species}
                    </div>
                    <p className="mt-1.5 text-xs leading-relaxed text-emerald-100/75">
                      {pet.description}
                    </p>
                    {pet.id !== 'none' && (
                      <div className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-white/10 pt-2 text-[11px] text-emerald-200/85">
                        <span>
                          Quýt Vàng:{' '}
                          <strong className="font-mono-num text-amber-300">
                            +{Math.round(pet.goldenYuzuBonus * 100)}%
                          </strong>
                        </span>
                        {pet.scoreBonusPct > 0 && (
                          <span>
                            Điểm quýt:{' '}
                            <strong className="font-mono-num text-white">+{pet.scoreBonusPct}%</strong>
                          </span>
                        )}
                        {pet.feverBonusPct > 0 && (
                          <span>
                            Nạp Chill:{' '}
                            <strong className="font-mono-num text-sky-300">+{pet.feverBonusPct}%</strong>
                          </span>
                        )}
                        {isUnlocked && (
                          <span>
                            Thân thiết:{' '}
                            <strong className="font-mono-num text-rose-300">{bond}%</strong>
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="mt-3">
                    <button
                      type="button"
                      disabled={!isUnlocked && !canAfford}
                      onClick={() => onSelectOrUnlockPet(pet.id)}
                      className={`inline-flex h-10 w-full items-center justify-center gap-1.5 whitespace-nowrap rounded-lg px-3 text-xs font-bold transition-colors ${
                        isSelected
                          ? 'border border-emerald-400/40 bg-emerald-500/20 text-emerald-300'
                          : isUnlocked
                          ? 'bg-[#23372E] text-white hover:bg-[#2E473C]'
                          : canAfford
                          ? 'bg-amber-500 text-[#1A1308] hover:bg-amber-400'
                          : 'cursor-not-allowed bg-white/5 text-white/35'
                      }`}
                    >
                      {isSelected ? (
                        <>
                          <Check className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Đang đi theo</span>
                        </>
                      ) : isUnlocked ? (
                        <span>Mang theo ngay</span>
                      ) : canAfford ? (
                        <span>Nhận nuôi ({pet.cost} quýt)</span>
                      ) : (
                        <>
                          <Lock className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Cần {pet.cost} quýt</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Shop Area */}
      {area === 'shop' && (
        <div className="mt-4 space-y-4">
          <div className="grid grid-cols-2 gap-1.5 rounded-lg bg-[#0F1814] p-1 sm:grid-cols-5">
            {(
              [
                { id: 'skills', label: 'Kỹ năng Boss' },
                { id: 'pets', label: 'Thú cưng nhỏ' },
                { id: 'food', label: 'Thức ăn' },
                { id: 'outfit', label: 'Trang phục & Lông' },
                { id: 'home_decor', label: 'Nội thất Nhà' },
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setShopTab(t.id)}
                className={`h-9 whitespace-nowrap rounded-md px-2 text-xs font-semibold transition-colors ${
                  shopTab === t.id
                    ? 'bg-[#263C31] text-amber-300'
                    : 'text-emerald-100/70 hover:text-white'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Boss Skills Shop with Detailed Descriptions & Tooltips */}
          {shopTab === 'skills' && (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {BOSS_SKILLS.map((skill) => {
                const isUnlocked = unlockedSkills.includes(skill.id);
                const canAfford = yuzuBank >= skill.cost;
                const isTooltipOpen = hoveredSkillId === skill.id || pinnedSkillId === skill.id;

                return (
                  <div
                    key={skill.id}
                    className={`relative flex flex-col justify-between rounded-xl border p-3.5 transition-colors ${
                      isUnlocked
                        ? 'border-emerald-400/35 bg-[#192921]'
                        : 'border-white/10 bg-[#14201A]'
                    }`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span
                              className="h-4 w-4 shrink-0 rounded-sm border border-white/20"
                              style={{ backgroundColor: skill.accentColor }}
                              aria-hidden="true"
                            />
                            <span className="font-display text-sm font-bold text-white">
                              [{skill.hotkey}] {skill.name}
                            </span>
                          </div>
                          <div className="mt-1 text-[11px] font-semibold text-amber-300/85">
                            {skill.roleLabel}
                          </div>
                        </div>

                        <div className="flex shrink-0 items-center gap-1.5">
                          <span className="font-mono-num text-xs text-emerald-200/80">
                            {isUnlocked ? 'Sẵn sàng' : `${skill.cost} quýt`}
                          </span>

                          <div
                            className="relative"
                            onMouseEnter={() => setHoveredSkillId(skill.id)}
                            onMouseLeave={() =>
                              setHoveredSkillId((curr) => (curr === skill.id ? null : curr))
                            }
                          >
                            <button
                              type="button"
                              aria-label={`Xem chi tiết kỹ năng ${skill.name}`}
                              aria-expanded={isTooltipOpen}
                              title={`${skill.name}: ${skill.detailedEffect} (${skill.tacticalTip})`}
                              onClick={() =>
                                setPinnedSkillId((curr) => (curr === skill.id ? null : skill.id))
                              }
                              onFocus={() => setHoveredSkillId(skill.id)}
                              onBlur={() =>
                                setHoveredSkillId((curr) => (curr === skill.id ? null : curr))
                              }
                              className={`inline-flex h-8 w-8 items-center justify-center rounded-lg border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 ${
                                isTooltipOpen
                                  ? 'border-amber-400/60 bg-amber-500/20 text-amber-200'
                                  : 'border-white/15 bg-[#0F1814] text-emerald-200/75 hover:border-amber-400/40 hover:text-white'
                              }`}
                            >
                              <Info className="h-4 w-4" aria-hidden="true" />
                            </button>

                            {isTooltipOpen && (
                              <div
                                role="tooltip"
                                className="absolute right-0 top-full z-30 mt-2 w-64 rounded-xl border border-amber-400/40 bg-[#0D1612] p-3 text-left shadow-2xl"
                              >
                                <div className="font-display text-xs font-bold text-amber-300">
                                  Chi tiết kỹ năng [{skill.hotkey}]
                                </div>
                                <p className="mt-1 text-xs leading-relaxed text-emerald-50/90">
                                  {skill.detailedEffect}
                                </p>
                                <div className="mt-2 border-t border-white/10 pt-2 text-[11px] leading-relaxed text-emerald-200/80">
                                  <span className="font-semibold text-white">Mẹo chiến thuật: </span>
                                  {skill.tacticalTip}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      <p className="mt-2 text-xs leading-relaxed text-emerald-100/85">
                        {skill.detailedEffect}
                      </p>

                      <div className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-white/10 pt-2 text-[11px] text-emerald-200/80">
                        <span>
                          Sát thương:{' '}
                          <strong className="font-mono-num text-white">
                            {skill.damage > 0 ? `${skill.damage} HP` : 'Chặn đòn + Hồi 1 tim'}
                          </strong>
                        </span>
                        <span>
                          Hồi chiêu:{' '}
                          <strong className="font-mono-num text-white">{skill.cooldown}s</strong>
                        </span>
                        <span>
                          Phím:{' '}
                          <strong className="font-mono-num text-amber-300">{skill.hotkey}</strong>
                        </span>
                      </div>
                    </div>

                    <div className="mt-3">
                      {isUnlocked ? (
                        <div className="inline-flex h-10 w-full items-center justify-center gap-1.5 rounded-lg border border-emerald-400/35 bg-emerald-500/15 px-3 text-xs font-bold text-emerald-300">
                          <Check className="h-3.5 w-3.5" aria-hidden="true" />
                          <span>Đã trang bị khi đấu Boss</span>
                        </div>
                      ) : (
                        <button
                          type="button"
                          disabled={!canAfford}
                          onClick={() => onUnlockSkill(skill.id)}
                          className={`inline-flex h-10 w-full items-center justify-center gap-1.5 whitespace-nowrap rounded-lg px-3 text-xs font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 ${
                            canAfford
                              ? 'bg-amber-500 text-[#1A1308] hover:bg-amber-400'
                              : 'cursor-not-allowed bg-white/5 text-white/35'
                          }`}
                        >
                          {canAfford ? (
                            <span>Mua kỹ năng ({skill.cost} quýt)</span>
                          ) : (
                            <>
                              <Lock className="h-3.5 w-3.5" aria-hidden="true" />
                              <span>Cần {skill.cost} quýt</span>
                            </>
                          )}
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Food Shop */}
          {shopTab === 'food' && (
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {FOOD_ITEMS.map((food) => {
                const count = foodInventory[food.id] ?? 0;
                const canAfford = yuzuBank >= food.cost;
                return (
                  <div
                    key={food.id}
                    className="flex flex-col justify-between rounded-xl border border-white/10 bg-[#14201A] p-3.5"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="flex items-center gap-2">
                          <span
                            className="h-3.5 w-3.5 shrink-0 rounded-sm border border-white/20"
                            style={{ backgroundColor: food.accentColor }}
                            aria-hidden="true"
                          />
                          <span className="font-display text-sm font-bold text-white">
                            {food.name}
                          </span>
                        </span>
                        <span className="font-mono-num text-xs text-emerald-200/80">
                          Đang có: {count}
                        </span>
                      </div>
                      <p className="mt-1.5 text-xs leading-relaxed text-emerald-100/75">
                        {food.description}
                      </p>
                      <div className="mt-2 text-[11px] text-emerald-200/80">
                        +{food.hungerGain}% No · +{food.energyGain}% Năng lượng · +{food.happinessGain}% Vui
                      </div>
                    </div>
                    <div className="mt-3">
                      <button
                        type="button"
                        disabled={!canAfford}
                        onClick={() => onBuyFood(food.id)}
                        className={`inline-flex h-10 w-full items-center justify-center whitespace-nowrap rounded-lg px-3 text-xs font-bold transition-colors ${
                          canAfford
                            ? 'bg-amber-500 text-[#1A1308] hover:bg-amber-400'
                            : 'cursor-not-allowed bg-white/5 text-white/35'
                        }`}
                      >
                        {canAfford ? `Mua vào kho (${food.cost} quýt)` : `Cần ${food.cost} quýt`}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Outfit & Fur Shop */}
          {shopTab === 'outfit' && (
            <div className="space-y-4">
              <div>
                <h3 className="mb-2 text-xs font-bold text-emerald-200">Màu lông</h3>
                {renderOutfitCards(FUR_OPTIONS, unlockedFur, appearance.fur, onSelectOrUnlockFur, false)}
              </div>
              <div>
                <h3 className="mb-2 text-xs font-bold text-emerald-200">Phụ kiện đầu</h3>
                {renderOutfitCards(
                  HEAD_ACCESSORIES,
                  unlockedHead,
                  appearance.head,
                  onSelectOrUnlockHead,
                  false
                )}
              </div>
              <div>
                <h3 className="mb-2 text-xs font-bold text-emerald-200">Phụ kiện cổ</h3>
                {renderOutfitCards(
                  NECK_ACCESSORIES,
                  unlockedNeck,
                  appearance.neck,
                  onSelectOrUnlockNeck,
                  false
                )}
              </div>
            </div>
          )}

          {/* Home Furniture Shop */}
          {shopTab === 'home_decor' && (
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {HOME_ITEMS.map((item) => {
                const isUnlocked = unlockedHomeItems.includes(item.id);
                const isPlaced = activeHomeItems.includes(item.id);
                const canAfford = yuzuBank >= item.cost;

                return (
                  <div
                    key={item.id}
                    className={`flex flex-col justify-between rounded-xl border p-3.5 ${
                      isUnlocked
                        ? 'border-emerald-400/35 bg-[#192921]'
                        : 'border-white/10 bg-[#14201A]'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="flex items-center gap-2">
                          <span
                            className="h-4 w-4 shrink-0 rounded-sm border border-white/20"
                            style={{ backgroundColor: item.accentColor }}
                            aria-hidden="true"
                          />
                          <span className="font-display text-sm font-bold text-white">
                            {item.name}
                          </span>
                        </span>
                        <span className="font-mono-num text-xs text-emerald-200/80">
                          {isUnlocked ? 'Đã sở hữu' : `${item.cost} quýt`}
                        </span>
                      </div>
                      <p className="mt-1.5 text-xs leading-relaxed text-emerald-100/75">
                        {item.description}
                      </p>
                    </div>
                    <div className="mt-3">
                      <button
                        type="button"
                        disabled={!isUnlocked && !canAfford}
                        onClick={() => onUnlockOrToggleHomeItem(item.id)}
                        className={`inline-flex h-10 w-full items-center justify-center whitespace-nowrap rounded-lg px-3 text-xs font-bold transition-colors ${
                          isPlaced
                            ? 'border border-emerald-400/40 bg-emerald-500/20 text-emerald-300'
                            : isUnlocked
                            ? 'bg-[#23372E] text-white hover:bg-[#2E473C]'
                            : canAfford
                            ? 'bg-amber-500 text-[#1A1308] hover:bg-amber-400'
                            : 'cursor-not-allowed bg-white/5 text-white/35'
                        }`}
                      >
                        {isPlaced
                          ? 'Đang đặt trong Nhà'
                          : isUnlocked
                          ? 'Đặt vào Nhà riêng'
                          : canAfford
                          ? `Mua nội thất (${item.cost} quýt)`
                          : `Cần ${item.cost} quýt`}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Small Pets Shop Sub-tab */}
          {shopTab === 'pets' && (
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {PET_OPTIONS.filter((p) => p.id !== 'none').map((pet) => {
                const isUnlocked = unlockedPets.includes(pet.id);
                const isSelected = selectedPet === pet.id;
                const canAfford = yuzuBank >= pet.cost;
                return (
                  <div
                    key={pet.id}
                    className={`flex flex-col justify-between rounded-xl border p-3.5 ${
                      isSelected
                        ? 'border-amber-400/50 bg-[#1D2E26]'
                        : isUnlocked
                        ? 'border-emerald-400/35 bg-[#192921]'
                        : 'border-white/10 bg-[#14201A]'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="flex items-center gap-2">
                          <span
                            className="h-4 w-4 shrink-0 rounded-sm border border-white/20"
                            style={{ backgroundColor: pet.accentColor }}
                            aria-hidden="true"
                          />
                          <span className="font-display text-sm font-bold text-white">
                            {pet.name}
                          </span>
                        </span>
                        <span className="font-mono-num text-xs text-emerald-200/80">
                          {isUnlocked ? 'Đã nhận nuôi' : `${pet.cost} quýt`}
                        </span>
                      </div>
                      <p className="mt-1.5 text-xs leading-relaxed text-emerald-100/75">
                        {pet.description}
                      </p>
                      <div className="mt-2 text-[11px] font-medium text-amber-300">
                        Buff Endless: +{Math.round(pet.goldenYuzuBonus * 100)}% tỉ lệ rơi Quýt Vàng
                      </div>
                    </div>
                    <div className="mt-3">
                      <button
                        type="button"
                        disabled={!isUnlocked && !canAfford}
                        onClick={() => onSelectOrUnlockPet(pet.id)}
                        className={`inline-flex h-10 w-full items-center justify-center whitespace-nowrap rounded-lg px-3 text-xs font-bold transition-colors ${
                          isSelected
                            ? 'border border-emerald-400/40 bg-emerald-500/20 text-emerald-300'
                            : isUnlocked
                            ? 'bg-[#23372E] text-white hover:bg-[#2E473C]'
                            : canAfford
                            ? 'bg-amber-500 text-[#1A1308] hover:bg-amber-400'
                            : 'cursor-not-allowed bg-white/5 text-white/35'
                        }`}
                      >
                        {isSelected
                          ? 'Đang đi theo'
                          : isUnlocked
                          ? 'Mang theo ngay'
                          : canAfford
                          ? `Nhận nuôi (${pet.cost} quýt)`
                          : `Cần ${pet.cost} quýt`}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Achievements Area */}
      {area === 'achievements' && (
        <div className="mt-4 space-y-4">
          {/* Lifetime Milestone Summary Strip */}
          <div className="grid grid-cols-2 gap-3 rounded-xl border border-white/10 bg-[#14201A] p-4 sm:grid-cols-4">
            <div>
              <div className="text-[11px] text-emerald-200/70">Huy hiệu đã nhận</div>
              <div className="mt-0.5 font-mono-num text-lg font-bold text-white">
                {claimedAchievements.length} / {ACHIEVEMENTS.length}
              </div>
            </div>
            <div>
              <div className="text-[11px] text-emerald-200/70">Quãng đường tích lũy</div>
              <div className="mt-0.5 font-mono-num text-lg font-bold text-amber-300">
                {achievementStats.totalDistanceMeters.toLocaleString('vi-VN')}m
              </div>
            </div>
            <div>
              <div className="text-[11px] text-emerald-200/70">Tổng Boss đã hạ</div>
              <div className="mt-0.5 font-mono-num text-lg font-bold text-rose-300">
                {achievementStats.totalBossesDefeated}
              </div>
            </div>
            <div>
              <div className="text-[11px] text-emerald-200/70">Combo cao nhất</div>
              <div className="mt-0.5 font-mono-num text-lg font-bold text-emerald-300">
                x{achievementStats.maxComboEver}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {ACHIEVEMENTS.map((ach) => {
              const current = getAchievementValue(ach, achievementStats, unlockedPets);
              const unlocked = isAchievementUnlocked(ach, achievementStats, unlockedPets);
              const claimed = claimedAchievements.includes(ach.id);
              const pct = Math.min(100, Math.round((current / ach.target) * 100));
              const tierStyle = TIER_STYLES[ach.tier];
              const BadgeIcon = getAchievementIcon(ach.id);

              return (
                <div
                  key={ach.id}
                  className={`flex flex-col justify-between rounded-xl border p-4 transition-colors ${
                    claimed
                      ? 'border-emerald-400/35 bg-[#192921]'
                      : unlocked
                      ? 'border-amber-400/60 bg-[#1F2F25]'
                      : 'border-white/10 bg-[#14201A]'
                  }`}
                >
                  <div>
                    <div className="flex items-start gap-3">
                      <div
                        className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border ${
                          unlocked
                            ? tierStyle.frameClass
                            : 'border-white/10 bg-[#0F1814] text-white/30'
                        }`}
                      >
                        <BadgeIcon className="h-5 w-5" aria-hidden="true" />
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <h3 className="font-display text-sm font-bold text-white">
                            {ach.title}
                          </h3>
                          <span className="font-mono-num text-xs font-bold text-amber-300">
                            +{ach.rewardYuzu} Quýt
                          </span>
                        </div>
                        <div className="mt-0.5 text-[11px] text-emerald-200/75">
                          <span className={unlocked ? tierStyle.textClass : 'text-emerald-200/60'}>
                            {ach.badgeLabel}
                          </span>
                          <span className="mx-1.5 text-white/25" aria-hidden="true">
                            ·
                          </span>
                          <span>{tierStyle.label}</span>
                        </div>
                      </div>
                    </div>

                    <p className="mt-2.5 text-xs leading-relaxed text-emerald-100/75">
                      {ach.description}
                    </p>

                    <div className="mt-3">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-emerald-200/75">Tiến độ</span>
                        <span className="font-mono-num font-semibold text-white">
                          {Math.min(current, ach.target).toLocaleString('vi-VN')} /{' '}
                          {ach.target.toLocaleString('vi-VN')}
                        </span>
                      </div>
                      <div className="mt-1.5 h-2 w-full overflow-hidden rounded-sm bg-[#0D1612]">
                        <div
                          className={`h-full transition-all duration-300 ${
                            claimed
                              ? 'bg-emerald-400'
                              : unlocked
                              ? 'bg-amber-400'
                              : 'bg-sky-400/80'
                          }`}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mt-3.5">
                    {claimed ? (
                      <div className="inline-flex h-10 w-full items-center justify-center gap-1.5 rounded-lg border border-emerald-400/35 bg-emerald-500/15 px-3 text-xs font-bold text-emerald-300">
                        <Check className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Đã nhận huy hiệu (+{ach.rewardYuzu} Quýt)</span>
                      </div>
                    ) : unlocked ? (
                      <button
                        type="button"
                        onClick={() => {
                          onClaimAchievement(ach.id);
                          setStatusMessage(
                            `Đã nhận ${ach.badgeLabel} và +${ach.rewardYuzu} Quýt thưởng!`
                          );
                        }}
                        className="inline-flex h-10 w-full items-center justify-center gap-1.5 whitespace-nowrap rounded-lg bg-amber-500 px-3 text-xs font-bold text-[#1A1308] transition-colors hover:bg-amber-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-300"
                      >
                        <Trophy className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Nhận huy hiệu (+{ach.rewardYuzu} Quýt)</span>
                      </button>
                    ) : (
                      <div className="inline-flex h-10 w-full items-center justify-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 text-xs font-medium text-white/45">
                        <Lock className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Chưa mở khóa ({pct}%)</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </section>
  );
}
