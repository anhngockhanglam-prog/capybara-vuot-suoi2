import {
  CapybaraActivityId,
  CapybaraNeeds,
  FoodId,
  FoodItemDefinition,
  HomeItemDefinition,
  WorldAreaId,
  WorldLocationId,
} from './types';

export interface WorldAreaMeta {
  id: WorldAreaId;
  label: string;
  subtitle: string;
}

export interface ExploreLocationMeta {
  id: Exclude<WorldLocationId, 'home' | 'pool' | 'forest' | 'playground'>;
  label: string;
  subtitle: string;
  accentColor: string;
}

export interface CapybaraActivityMeta {
  id: CapybaraActivityId;
  label: string;
  shortLabel: string;
  description: string;
  recommendedLocation: WorldLocationId;
  energyDelta: number;
  happinessDelta: number;
  hungerDelta: number;
  yuzuReward?: number;
  accentColor: string;
}

export const WORLD_AREAS: WorldAreaMeta[] = [
  {
    id: 'home',
    label: 'Nhà riêng',
    subtitle: 'Nghỉ ngơi, ôm gấu bông, chơi máy điện tử và bài trí nội thất gỗ ấm áp.',
  },
  {
    id: 'pool',
    label: 'Hồ bơi',
    subtitle: 'Tắm bồn bong bóng, bơi và lặn dưới nước mát, giải tỏa căng thẳng.',
  },
  {
    id: 'forest',
    label: 'Khu rừng',
    subtitle: 'Dạo bước dưới tán tre, hái quýt và tìm nguyên liệu tươi.',
  },
  {
    id: 'playground',
    label: 'Khu vui chơi',
    subtitle: 'Nhảy theo nhạc, chơi bóng bay, chụp selfie và bắt quýt nhận thưởng.',
  },
  {
    id: 'explore',
    label: 'Du lịch',
    subtitle: 'Khám phá thành phố, bãi biển, đảo núi lửa, rừng bí mật, cắm trại, mùa đông & công viên.',
  },
  {
    id: 'shop',
    label: 'Cửa hàng',
    subtitle: 'Mua kỹ năng Boss, thức ăn, trang phục, thú cưng và đồ nội thất.',
  },
  {
    id: 'wardrobe',
    label: 'Tủ quần áo',
    subtitle: 'Thay đổi màu lông và phụ kiện đã sở hữu nhanh chóng.',
  },
  {
    id: 'food',
    label: 'Thức ăn',
    subtitle: 'Cho Capybara ăn no để kích hoạt +1 Tim khi vào trận.',
  },
  {
    id: 'pets',
    label: 'Thú cưng',
    subtitle: 'Nhận nuôi, chăm sóc thú cưng đi theo và tăng tỉ lệ rơi Quýt Vàng.',
  },
  {
    id: 'achievements',
    label: 'Thành tựu',
    subtitle: 'Chinh phục các cột mốc vượt suối và diệt Boss để mở huy hiệu nhận Quýt.',
  },
];

export const EXPLORE_LOCATIONS: ExploreLocationMeta[] = [
  {
    id: 'city',
    label: 'Thành phố',
    subtitle: 'Phố đèn đường hiện đại lý tưởng để trượt ván quanh thành phố.',
    accentColor: '#38BDF8',
  },
  {
    id: 'beach',
    label: 'Bãi biển',
    subtitle: 'Cát vàng nắng ấm, rặng dừa xanh, sóng biển vỗ và chú cua nhỏ.',
    accentColor: '#FBBF24',
  },
  {
    id: 'volcano',
    label: 'Đảo núi lửa',
    subtitle: 'Đỉnh núi lửa bốc khói, hồ dung nham rực sáng và tàn lửa bay lên.',
    accentColor: '#FB7185',
  },
  {
    id: 'secret_forest',
    label: 'Rừng bí mật',
    subtitle: 'Khu rừng cổ thụ huyền ảo với nấm phát sáng và đom đóm xanh lam.',
    accentColor: '#34D399',
  },
  {
    id: 'campsite',
    label: 'Khu cắm trại',
    subtitle: 'Lều vải ấm cúng bên đống lửa trại bập bùng dưới bầu trời sao.',
    accentColor: '#F97316',
  },
  {
    id: 'winter',
    label: 'Mùa đông tuyết',
    subtitle: 'Rừng thông phủ tuyết trắng, người tuyết dễ thương và bông tuyết rơi.',
    accentColor: '#BAE6FD',
  },
  {
    id: 'amusement_park',
    label: 'Công viên giải trí',
    subtitle: 'Vòng đu quay rực rỡ, cờ lễ hội và quầy bóng bay đầy màu sắc.',
    accentColor: '#F472B6',
  },
];

export const CAPYBARA_ACTIVITIES: CapybaraActivityMeta[] = [
  {
    id: 'skateboard',
    label: 'Trượt ván quanh thành phố',
    shortLabel: 'Trượt ván',
    description: 'Capybara lướt ván điệu nghệ qua phố phường và bật nhảy tạo tia lửa.',
    recommendedLocation: 'city',
    energyDelta: -4,
    happinessDelta: 22,
    hungerDelta: -3,
    yuzuReward: 1,
    accentColor: '#38BDF8',
  },
  {
    id: 'bubble_bath',
    label: 'Tắm bồn bong bóng xà phòng',
    shortLabel: 'Tắm bong bóng',
    description: 'Ngâm mình trong bồn ấm đầy bọt xà phòng óng ánh bay lơ lửng.',
    recommendedLocation: 'pool',
    energyDelta: 18,
    happinessDelta: 24,
    hungerDelta: -2,
    accentColor: '#67E8F9',
  },
  {
    id: 'nap_snore',
    label: 'Ngủ và ngáy',
    shortLabel: 'Ngủ & ngáy',
    description: 'Đánh một giấc thật say với tiếng ngáy khò khò cực chill.',
    recommendedLocation: 'home',
    energyDelta: 35,
    happinessDelta: 10,
    hungerDelta: -3,
    accentColor: '#93C5FD',
  },
  {
    id: 'dance',
    label: 'Nhảy theo nhạc',
    shortLabel: 'Nhảy theo nhạc',
    description: 'Lắc lư nhịp nhàng dưới ánh đèn sân khấu cùng nốt nhạc rộn ràng.',
    recommendedLocation: 'playground',
    energyDelta: -5,
    happinessDelta: 26,
    hungerDelta: -4,
    yuzuReward: 1,
    accentColor: '#C084FC',
  },
  {
    id: 'eat_watermelon',
    label: 'Ăn dưa hấu (hoạt ảnh nhai)',
    shortLabel: 'Ăn dưa hấu',
    description: 'Cầm miếng dưa hấu đỏ mọng nhai ngon lành và giải nhiệt tức thì.',
    recommendedLocation: 'beach',
    energyDelta: 14,
    happinessDelta: 18,
    hungerDelta: 28,
    accentColor: '#FB7185',
  },
  {
    id: 'dive_swim',
    label: 'Bơi và lặn dưới nước',
    shortLabel: 'Bơi & lặn',
    description: 'Lặn sâu xuống làn nước trong vắt ngắm cá nhỏ và sủi bọt khí.',
    recommendedLocation: 'pool',
    energyDelta: -3,
    happinessDelta: 22,
    hungerDelta: -4,
    yuzuReward: 2,
    accentColor: '#0EA5E9',
  },
  {
    id: 'balloon',
    label: 'Chơi với bóng bay',
    shortLabel: 'Chơi bóng bay',
    description: 'Tâng những quả bóng bay rực rỡ lên không trung đầy hào hứng.',
    recommendedLocation: 'amusement_park',
    energyDelta: -3,
    happinessDelta: 24,
    hungerDelta: -2,
    accentColor: '#F472B6',
  },
  {
    id: 'sleep_teddy',
    label: 'Ôm gấu bông khi ngủ',
    shortLabel: 'Ôm gấu bông',
    description: 'Ôm chặt chú gấu bông mềm mại ngủ ngon lành ấm áp.',
    recommendedLocation: 'home',
    energyDelta: 42,
    happinessDelta: 18,
    hungerDelta: -2,
    accentColor: '#FBBF24',
  },
  {
    id: 'selfie',
    label: 'Chụp ảnh selfie',
    shortLabel: 'Chụp selfie',
    description: 'Tạo dáng dễ thương trước ống kính với ánh đèn flash lấp lánh.',
    recommendedLocation: 'campsite',
    energyDelta: 0,
    happinessDelta: 20,
    hungerDelta: 0,
    yuzuReward: 1,
    accentColor: '#FDE047',
  },
  {
    id: 'arcade_game',
    label: 'Chơi máy điện tử',
    shortLabel: 'Chơi điện tử',
    description: 'Trổ tài phá đảo máy thùng cổ điển và rinh thêm quýt thưởng.',
    recommendedLocation: 'home',
    energyDelta: -4,
    happinessDelta: 25,
    hungerDelta: -3,
    yuzuReward: 2,
    accentColor: '#4ADE80',
  },
];

export const FOOD_ITEMS: FoodItemDefinition[] = [
  {
    id: 'carrot',
    name: 'Cà rốt tươi',
    description: 'Giòn ngọt thanh mát, giúp Capybara no bụng nhanh chóng.',
    cost: 5,
    hungerGain: 25,
    energyGain: 10,
    happinessGain: 6,
    accentColor: '#F97316',
  },
  {
    id: 'yuzu_sweet',
    name: 'Quýt Yuzu ngọt',
    description: 'Món khoái khẩu giúp tinh thần Capybara phấn chấn tức thì.',
    cost: 8,
    hungerGain: 18,
    energyGain: 12,
    happinessGain: 22,
    accentColor: '#FBBF24',
  },
  {
    id: 'watermelon',
    name: 'Dưa hấu mát lạnh',
    description: 'Giải nhiệt sau khi bơi lội và hồi phục nhiều năng lượng.',
    cost: 12,
    hungerGain: 32,
    energyGain: 18,
    happinessGain: 16,
    accentColor: '#FB7185',
  },
  {
    id: 'bamboo_salad',
    name: 'Salad tre non',
    description: 'Bữa ăn giàu dinh dưỡng giúp giữ độ no rất lâu.',
    cost: 15,
    hungerGain: 42,
    energyGain: 22,
    happinessGain: 12,
    accentColor: '#34D399',
  },
  {
    id: 'mochi',
    name: 'Bánh Mochi đậu đỏ',
    description: 'Tráng miệng thượng hạng hồi mạnh cả năng lượng lẫn niềm vui.',
    cost: 18,
    hungerGain: 28,
    energyGain: 32,
    happinessGain: 28,
    accentColor: '#F472B6',
  },
];

export const HOME_ITEMS: HomeItemDefinition[] = [
  {
    id: 'tatami',
    name: 'Chiếu Tatami ấm',
    description: 'Thảm cói truyền thống trải giữa phòng cho Capybara nằm thư giãn.',
    cost: 0,
    accentColor: '#A3B18A',
  },
  {
    id: 'tea_table',
    name: 'Bàn trà Yuzu',
    description: 'Bàn gỗ thấp bày ấm trà nóng và đĩa quýt thơm lừng.',
    cost: 22,
    accentColor: '#D97706',
  },
  {
    id: 'lantern',
    name: 'Đèn lồng giấy',
    description: 'Ánh sáng vàng dịu nhẹ giúp căn nhà luôn ấm cúng vào ban đêm.',
    cost: 30,
    accentColor: '#FCD34D',
  },
  {
    id: 'plush_bed',
    name: 'Giường đệm êm',
    description: 'Nệm bông dày giúp giấc ngủ trưa hồi thêm +10 Năng lượng.',
    cost: 42,
    accentColor: '#38BDF8',
  },
  {
    id: 'bonsai',
    name: 'Chậu Bonsai mini',
    description: 'Cây xanh phong thủy mang hơi thở khu rừng vào trong nhà.',
    cost: 35,
    accentColor: '#10B981',
  },
];

export function clampStat(val: number): number {
  return Math.max(0, Math.min(100, Math.round(val)));
}

export function hasWellFedBuff(needs: CapybaraNeeds): boolean {
  return needs.hunger >= 70 && needs.happiness >= 60;
}

export function createDefaultFoodInventory(): Record<FoodId, number> {
  return {
    carrot: 2,
    yuzu_sweet: 2,
    watermelon: 0,
    mochi: 0,
    bamboo_salad: 0,
  };
}
