import { PetDefinition, PetId } from './types';

export const PET_OPTIONS: PetDefinition[] = [
  {
    id: 'none',
    name: 'Không mang thú cưng',
    species: 'Một mình tự tại',
    description: 'Chạy bộ thư giãn cùng chú Capybara trên dòng suối xanh.',
    cost: 0,
    goldenYuzuBonus: 0,
    scoreBonusPct: 0,
    feverBonusPct: 0,
    accentColor: '#64748B',
    favoriteFoodLabel: 'Quýt tươi',
  },
  {
    id: 'duckling',
    name: 'Vịt Vàng Onsen',
    species: 'Vịt con lạch bạch',
    description:
      'Chú vịt vàng nhỏ luôn chạy lon ton theo sau, giúp đánh hơi quýt chín và tăng điểm nhặt quýt trong Endless.',
    cost: 25,
    goldenYuzuBonus: 0.06,
    scoreBonusPct: 10,
    feverBonusPct: 0,
    accentColor: '#FACC15',
    favoriteFoodLabel: 'Hạt bắp & Quýt',
  },
  {
    id: 'frog',
    name: 'Ếch Cốm Rừng Tre',
    species: 'Ếch xanh đội lá',
    description:
      'Chú ếch tinh nghịch nhảy cao theo từng bước chạy, cực nhạy với Quýt Vàng giúp tăng mạnh tỉ lệ rơi Quýt Vàng trong Endless.',
    cost: 40,
    goldenYuzuBonus: 0.09,
    scoreBonusPct: 5,
    feverBonusPct: 0,
    accentColor: '#4ADE80',
    favoriteFoodLabel: 'Bánh cốm & Chuồn chuồn',
  },
  {
    id: 'turtle',
    name: 'Rùa Con Suối Mát',
    species: 'Rùa mai ngọc',
    description:
      'Bé rùa điềm tĩnh mang lại may mắn kép: tăng tỉ lệ rơi Quýt Vàng và nạp nhanh thanh Suối Nước Nóng (Chill/Fever).',
    cost: 55,
    goldenYuzuBonus: 0.05,
    scoreBonusPct: 5,
    feverBonusPct: 20,
    accentColor: '#2DD4BF',
    favoriteFoodLabel: 'Salad tre non',
  },
];

export function getPetDef(id: PetId): PetDefinition {
  return PET_OPTIONS.find((p) => p.id === id) ?? PET_OPTIONS[0];
}

export function getPetEffectiveGoldenBonus(petId: PetId, bond: number): number {
  const def = getPetDef(petId);
  if (def.id === 'none') return 0;
  // Extra +0% to +2% when pet bond >= 70
  const bondBonus = bond >= 70 ? 0.02 : bond >= 45 ? 0.01 : 0;
  return def.goldenYuzuBonus + bondBonus;
}
