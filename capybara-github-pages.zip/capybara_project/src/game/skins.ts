import {
  CustomizationItem,
  Difficulty,
  DifficultyConfig,
  FurColorId,
  HeadAccessoryId,
  NeckAccessoryId,
} from './types';

export const FUR_OPTIONS: CustomizationItem<FurColorId>[] = [
  {
    id: 'classic',
    name: 'Nâu Cổ Điển',
    description: 'Màu lông nâu hạt dẻ ấm áp quen thuộc.',
    cost: 0,
    swatchColor: '#9C6B43',
    secondaryColor: '#6B4426',
  },
  {
    id: 'cream',
    name: 'Kem Sữa',
    description: 'Bộ lông kem vani dịu mắt bên suối khoáng.',
    cost: 15,
    swatchColor: '#DFC5A4',
    secondaryColor: '#A68863',
  },
  {
    id: 'honey',
    name: 'Vàng Mật Ong',
    description: 'Ánh lông vàng óng ả như nắng chiều.',
    cost: 30,
    swatchColor: '#C88A3B',
    secondaryColor: '#8C581E',
  },
  {
    id: 'mist',
    name: 'Xám Khói',
    description: 'Tông xám bạc thanh lịch giữa rừng tre.',
    cost: 45,
    swatchColor: '#8A949A',
    secondaryColor: '#566066',
  },
  {
    id: 'espresso',
    name: 'Sô-cô-la Đậm',
    description: 'Sắc nâu sẫm trầm ấm và chững chạc.',
    cost: 55,
    swatchColor: '#6E4730',
    secondaryColor: '#452A1B',
  },
];

export const HEAD_ACCESSORIES: CustomizationItem<HeadAccessoryId>[] = [
  {
    id: 'none',
    name: 'Tự nhiên',
    description: 'Để đầu trần khoe tháp quýt cân bằng.',
    cost: 0,
    swatchColor: '#64748B',
  },
  {
    id: 'towel',
    name: 'Khăn Tắm Onsen',
    description: 'Khăn bông trắng gấp gọn chuẩn suối nước nóng.',
    cost: 20,
    swatchColor: '#F8FAFC',
  },
  {
    id: 'lotus',
    name: 'Nón Lá Sen',
    description: 'Chiếc lá sen xanh mát che nắng và mưa phùn.',
    cost: 45,
    swatchColor: '#10B981',
  },
  {
    id: 'sunglasses',
    name: 'Kính Râm Ngầu',
    description: 'Kính đen phong thái bình thản trước mọi sóng gió.',
    cost: 70,
    swatchColor: '#1E293B',
  },
  {
    id: 'crown',
    name: 'Vương Miện Quýt',
    description: 'Vương miện vàng rực rỡ cho bậc thầy xếp quýt.',
    cost: 110,
    swatchColor: '#FBBF24',
  },
];

export const NECK_ACCESSORIES: CustomizationItem<NeckAccessoryId>[] = [
  {
    id: 'none',
    name: 'Không phụ kiện',
    description: 'Phong cách tối giản thoải mái.',
    cost: 0,
    swatchColor: '#64748B',
  },
  {
    id: 'scarf',
    name: 'Khăn Quàng Đỏ',
    description: 'Khăn len đỏ ấm áp bay nhẹ theo gió.',
    cost: 25,
    swatchColor: '#EF4444',
  },
  {
    id: 'bell',
    name: 'Chuông Vàng',
    description: 'Dây cổ xanh lục gắn chuông vàng leng keng.',
    cost: 40,
    swatchColor: '#F59E0B',
  },
  {
    id: 'sakura',
    name: 'Vòng Hoa Đào',
    description: 'Vòng hoa anh đào hồng dịu dàng mùa xuân.',
    cost: 65,
    swatchColor: '#F472B6',
  },
];

export const DIFFICULTY_CONFIGS: Record<Difficulty, DifficultyConfig> = {
  relaxed: {
    id: 'relaxed',
    label: 'Thư giãn',
    subtitle: 'Nhịp độ nhẹ nhàng · Phù hợp ngắm cảnh',
    baseSpeed: 310,
    maxSpeed: 540,
    spawnIntervalMin: 1.25,
    spawnIntervalMax: 2.05,
    scoreMultiplier: 1,
  },
  normal: {
    id: 'normal',
    label: 'Bình thường',
    subtitle: 'Cân bằng tốc độ · Thử thách combo',
    baseSpeed: 380,
    maxSpeed: 690,
    spawnIntervalMin: 0.92,
    spawnIntervalMax: 1.65,
    scoreMultiplier: 1.25,
  },
  turbo: {
    id: 'turbo',
    label: 'Siêu tốc',
    subtitle: 'Tốc độ cao · Điểm thưởng x1.6',
    baseSpeed: 460,
    maxSpeed: 840,
    spawnIntervalMin: 0.72,
    spawnIntervalMax: 1.35,
    scoreMultiplier: 1.6,
  },
};

export const DIFFICULTY_LIST: DifficultyConfig[] = [
  DIFFICULTY_CONFIGS.relaxed,
  DIFFICULTY_CONFIGS.normal,
  DIFFICULTY_CONFIGS.turbo,
];
