import { onAuthStateChanged, User } from 'firebase/auth';
import { Camera, Check, CloudRain, Download, X } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { CapybaraWorldHub } from './components/CapybaraWorldHub';
import { DailyQuestsPanel } from './components/DailyQuestsPanel';
import { GameCanvas } from './components/GameCanvas';
import { GameHud } from './components/GameHud';
import { GameOverOverlay } from './components/GameOverOverlay';
import { LeaderboardPanel } from './components/LeaderboardPanel';
import { MultiplayerView } from './components/MultiplayerView';
import { PauseOverlay } from './components/PauseOverlay';
import { TitleOverlay } from './components/TitleOverlay';
import {
  auth,
  claimYuzuGift,
  fetchPersonalLeaderboardEntry,
  fetchTodaySentGift,
  sendYuzuGift,
  signInWithGoogle,
  signOutGoogle,
  submitLeaderboardScore,
  subscribeIncomingGifts,
  subscribeTopLeaderboard,
  YUZU_GIFT_AMOUNT,
} from './game/firebase';
import {
  ACHIEVEMENTS,
  applyRunToAchievementStats,
  isAchievementUnlocked,
} from './game/achievements';
import { musicEngine } from './game/music';
import { PET_OPTIONS } from './game/pets';
import { applyRunToQuests, ensureCurrentDailyQuests } from './game/quests';
import { BOSS_SKILLS } from './game/skills';
import { FUR_OPTIONS, HEAD_ACCESSORIES, NECK_ACCESSORIES } from './game/skins';
import { soundEngine } from './game/sound';
import { generateNewStage } from './game/stages';
import { loadProgress, saveProgress } from './game/storage';
import {
  CapybaraActivityId,
  CustomMap,
  Difficulty,
  FoodId,
  FurColorId,
  GameState,
  GlobalLeaderboardEntry,
  HeadAccessoryId,
  HomeItemId,
  HudSnapshot,
  NeckAccessoryId,
  PetId,
  PhotoPose,
  PlayMode,
  RunSummary,
  SavedProgress,
  SkillId,
  StageConfig,
  WeatherMode,
  YuzuGift,
} from './game/types';
import { getWeatherLabel, resolveActiveWeather, WEATHER_OPTIONS } from './game/weather';
import {
  CAPYBARA_ACTIVITIES,
  clampStat,
  FOOD_ITEMS,
  HOME_ITEMS,
  hasWellFedBuff,
} from './game/world';

export default function App() {
  const [initialRoomCode] = useState<string>(() => {
    if (typeof window === 'undefined') return '';
    const params = new URLSearchParams(window.location.search);
    return (params.get('room') ?? '').trim().toUpperCase();
  });
  const [progress, setProgress] = useState<SavedProgress>(() => loadProgress());
  const [gameState, setGameState] = useState<GameState>('TITLE_MENU');
  const [playMode, setPlayMode] = useState<PlayMode>(() =>
    initialRoomCode ? 'multiplayer' : 'endless'
  );
  const [bossActive, setBossActive] = useState<boolean>(false);
  const [stageConfig, setStageConfig] = useState<StageConfig>(() => generateNewStage());
  const [runKey, setRunKey] = useState<number>(0);
  const [runSummary, setRunSummary] = useState<RunSummary | null>(null);
  const [audioUnlocked, setAudioUnlocked] = useState<boolean>(false);

  // Photo Mode state
  const [photoMode, setPhotoMode] = useState<boolean>(false);
  const [photoPose, setPhotoPose] = useState<PhotoPose>('happy');
  const [photoWithSignature, setPhotoWithSignature] = useState<boolean>(true);
  const [photoFlash, setPhotoFlash] = useState<boolean>(false);
  const [photoSavedNotice, setPhotoSavedNotice] = useState<boolean>(false);
  const resumeAfterPhotoRef = useRef<boolean>(false);
  const captureApiRef = useRef<((withSignature: boolean) => boolean) | null>(null);

  // Firebase Auth & Global Leaderboard state
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [authBusy, setAuthBusy] = useState<boolean>(false);
  const [leaderboardEntries, setLeaderboardEntries] = useState<GlobalLeaderboardEntry[]>([]);
  const [leaderboardLoading, setLeaderboardLoading] = useState<boolean>(true);
  const [leaderboardError, setLeaderboardError] = useState<string | null>(null);
  const [personalCloudEntry, setPersonalCloudEntry] = useState<GlobalLeaderboardEntry | null>(null);
  const [todaySentGift, setTodaySentGift] = useState<YuzuGift | null>(null);
  const [incomingGifts, setIncomingGifts] = useState<YuzuGift[]>([]);
  const [cloudStatus, setCloudStatus] = useState<
    'idle' | 'saving' | 'saved' | 'kept_best' | 'error'
  >('idle');

  const currentHighScore = progress.highScores[progress.selectedDifficulty] ?? 0;
  const overallLocalBest = Math.max(
    progress.highScores.relaxed ?? 0,
    progress.highScores.normal ?? 0,
    progress.highScores.turbo ?? 0
  );

  const [hud, setHud] = useState<HudSnapshot>({
    score: 0,
    highScore: currentHighScore,
    yuzuRun: 0,
    yuzuBank: progress.yuzuBank,
    combo: 0,
    multiplier: 1,
    hearts: 3,
    maxHearts: 3,
    hasShield: false,
    magnetTimer: 0,
    feverMeter: 0,
    feverActive: false,
    feverTimer: 0,
    distanceMeters: 0,
    speedFactor: 1,
    activeWeather: resolveActiveWeather(progress.weatherMode, 0),
    isNight: false,
    cycleRemainingSeconds: 300,
    bossActive: false,
    bossName: null,
    bossHp: 0,
    bossMaxHp: 1,
    bossesDefeated: 0,
    skillCooldowns: {
      yuzu_shot: 0,
      onsen_wave: 0,
      lotus_shield: 0,
      yuzu_meteor: 0,
    },
    stageName: stageConfig.name,
  });

  // Unlock Tone.js AudioContext on first user interaction
  useEffect(() => {
    const unlock = () => {
      setAudioUnlocked(true);
      void musicEngine.ensureReady();
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
    window.addEventListener('pointerdown', unlock);
    window.addEventListener('keydown', unlock);
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, []);

  // Persist progress and sync Mute state to both SFX and Tone.js BGM
  useEffect(() => {
    soundEngine.setMuted(progress.muted);
    musicEngine.setMuted(progress.muted);
    saveProgress(progress);
  }, [progress]);

  // Switch BGM tracks smoothly based on gameState, playMode, and bossActive
  useEffect(() => {
    if (!audioUnlocked) return;
    if (playMode === 'multiplayer') {
      void musicEngine.setTrack('playing');
      return;
    }
    if (gameState === 'PAUSED') {
      void musicEngine.setTrack('stopped');
    } else if (gameState === 'PLAYING') {
      void musicEngine.setTrack(bossActive ? 'boss' : 'playing');
    } else {
      void musicEngine.setTrack('menu');
    }
  }, [audioUnlocked, bossActive, gameState, playMode]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      if (user) {
        fetchPersonalLeaderboardEntry(user.uid)
          .then((entry) => setPersonalCloudEntry(entry))
          .catch(() => {});
        fetchTodaySentGift(user.uid)
          .then((gift) => setTodaySentGift(gift))
          .catch(() => {});
      } else {
        setPersonalCloudEntry(null);
        setTodaySentGift(null);
        setIncomingGifts([]);
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!firebaseUser) {
      setIncomingGifts([]);
      return;
    }
    const unsub = subscribeIncomingGifts(
      firebaseUser.uid,
      (gifts) => setIncomingGifts(gifts),
      () => {}
    );
    return () => unsub();
  }, [firebaseUser]);

  useEffect(() => {
    setLeaderboardLoading(true);
    const unsub = subscribeTopLeaderboard(
      (entries) => {
        setLeaderboardEntries(entries);
        setLeaderboardLoading(false);
        setLeaderboardError(null);
      },
      (err) => {
        setLeaderboardLoading(false);
        setLeaderboardError(
          err.message.includes('Quota')
            ? 'Hệ thống Firebase đã vượt hạn mức truy cập hôm nay. Vui lòng thử lại vào ngày mai.'
            : 'Không thể tải bảng xếp hạng toàn cầu lúc này.'
        );
      }
    );
    return () => unsub();
  }, []);

  const syncScoreToCloud = useCallback(
    async (
      user: User,
      score: number,
      difficulty: Difficulty,
      distanceMeters: number
    ) => {
      setCloudStatus('saving');
      try {
        const res = await submitLeaderboardScore({
          user,
          playerName: progress.appearance.name || user.displayName || 'Capybara',
          score,
          difficulty,
          distanceMeters,
          appearance: progress.appearance,
        });
        setCloudStatus(res.status === 'kept_best' ? 'kept_best' : 'saved');
        const updated = await fetchPersonalLeaderboardEntry(user.uid);
        if (updated) {
          setPersonalCloudEntry(updated);
        }
      } catch {
        setCloudStatus('error');
      }
    },
    [progress.appearance]
  );

  const handleToggleMute = useCallback(() => {
    setProgress((prev) => ({
      ...prev,
      muted: !prev.muted,
    }));
  }, []);

  const handleSelectDifficulty = useCallback((difficulty: Difficulty) => {
    setProgress((prev) => {
      setHud((prevHud) => ({
        ...prevHud,
        highScore: prev.highScores[difficulty] ?? 0,
      }));
      return {
        ...prev,
        selectedDifficulty: difficulty,
      };
    });
  }, []);

  const handleSelectWeather = useCallback((weatherMode: WeatherMode) => {
    setProgress((prev) => ({
      ...prev,
      weatherMode,
    }));
    setHud((prevHud) => ({
      ...prevHud,
      activeWeather: resolveActiveWeather(weatherMode, prevHud.distanceMeters * 28),
    }));
  }, []);

  const handleCycleWeather = useCallback(() => {
    setProgress((prev) => {
      const idx = WEATHER_OPTIONS.findIndex((w) => w.id === prev.weatherMode);
      const nextMode = WEATHER_OPTIONS[(idx + 1) % WEATHER_OPTIONS.length].id;
      setHud((prevHud) => ({
        ...prevHud,
        activeWeather: resolveActiveWeather(nextMode, prevHud.distanceMeters * 28),
      }));
      return {
        ...prev,
        weatherMode: nextMode,
      };
    });
  }, []);

  const handleStartEndless = useCallback(() => {
    setPhotoMode(false);
    setRunSummary(null);
    setCloudStatus('idle');
    setBossActive(false);
    setPlayMode('endless');
    setStageConfig((prev) => generateNewStage(prev.biome));
    setRunKey((k) => k + 1);
    setGameState('PLAYING');
  }, []);

  const handleStartBossRush = useCallback(() => {
    setPhotoMode(false);
    setRunSummary(null);
    setCloudStatus('idle');
    setBossActive(true);
    setPlayMode('boss_rush');
    setStageConfig((prev) => generateNewStage(prev.biome));
    setRunKey((k) => k + 1);
    setGameState('PLAYING');
  }, []);

  const handleOpenMultiplayer = useCallback(() => {
    setPhotoMode(false);
    setBossActive(false);
    setPlayMode('multiplayer');
  }, []);

  const handleExitMultiplayer = useCallback(() => {
    setPlayMode('endless');
    setGameState('TITLE_MENU');
  }, []);

  const handleTogglePause = useCallback(() => {
    setGameState((prev) => {
      if (prev === 'PLAYING') return 'PAUSED';
      if (prev === 'PAUSED') return 'PLAYING';
      return prev;
    });
  }, []);

  const handleBackToMenu = useCallback(() => {
    setPhotoMode(false);
    setRunSummary(null);
    setCloudStatus('idle');
    setBossActive(false);
    setStageConfig((prev) => generateNewStage(prev.biome));
    setRunKey((k) => k + 1);
    setGameState('TITLE_MENU');
  }, []);

  const handleOpenPhotoMode = useCallback(() => {
    setPhotoSavedNotice(false);
    if (gameState === 'PLAYING') {
      resumeAfterPhotoRef.current = true;
      setGameState('PAUSED');
    } else {
      resumeAfterPhotoRef.current = false;
    }
    setPhotoMode(true);
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [gameState]);

  const handleExitPhotoMode = useCallback(() => {
    setPhotoMode(false);
    setPhotoSavedNotice(false);
    if (resumeAfterPhotoRef.current) {
      resumeAfterPhotoRef.current = false;
      setGameState('PLAYING');
    }
  }, []);

  const handleCapturePhoto = useCallback(() => {
    const ok = captureApiRef.current?.(photoWithSignature);
    if (ok) {
      soundEngine.playPowerUp();
      setPhotoFlash(true);
      setPhotoSavedNotice(true);
      window.setTimeout(() => setPhotoFlash(false), 220);
      window.setTimeout(() => setPhotoSavedNotice(false), 2800);
    }
  }, [photoWithSignature]);

  useEffect(() => {
    if (!photoMode) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Escape') {
        e.preventDefault();
        handleExitPhotoMode();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [handleExitPhotoMode, photoMode]);

  const handleGameOver = useCallback(
    (summary: RunSummary) => {
      setRunSummary(summary);
      setBossActive(false);
      setGameState('GAME_OVER');
      setProgress((prev) => {
        const prevBest = prev.highScores[prev.selectedDifficulty] ?? 0;
        const nextBest = Math.max(prevBest, summary.score);
        return {
          ...prev,
          highScores: {
            ...prev.highScores,
            [prev.selectedDifficulty]: nextBest,
          },
          yuzuBank: prev.yuzuBank + summary.yuzuCollected,
          dailyQuests: applyRunToQuests(prev.dailyQuests, summary),
          achievementStats: applyRunToAchievementStats(prev.achievementStats, summary),
          needs: {
            hunger: clampStat(prev.needs.hunger - 8),
            energy: clampStat(prev.needs.energy - 10),
            happiness: clampStat(prev.needs.happiness + (summary.bossesDefeated > 0 ? 8 : 2)),
            updatedAt: Date.now(),
          },
        };
      });

      if (firebaseUser) {
        void syncScoreToCloud(
          firebaseUser,
          summary.score,
          progress.selectedDifficulty,
          summary.distanceMeters
        );
      }
    },
    [firebaseUser, progress.selectedDifficulty, syncScoreToCloud]
  );

  const handleSignIn = useCallback(
    async (scoreToSubmit?: { score: number; distanceMeters: number }) => {
      setAuthBusy(true);
      try {
        const user = await signInWithGoogle();
        const existing = await fetchPersonalLeaderboardEntry(user.uid);
        setPersonalCloudEntry(existing);
        if (scoreToSubmit && scoreToSubmit.score > (existing?.score ?? -1)) {
          await syncScoreToCloud(
            user,
            scoreToSubmit.score,
            progress.selectedDifficulty,
            scoreToSubmit.distanceMeters
          );
        }
      } catch {
        // User cancelled popup
      } finally {
        setAuthBusy(false);
      }
    },
    [progress.selectedDifficulty, syncScoreToCloud]
  );

  const handleSignOut = useCallback(async () => {
    await signOutGoogle();
    setPersonalCloudEntry(null);
    setCloudStatus('idle');
  }, []);

  const handleSyncLocalBest = useCallback(() => {
    if (!firebaseUser || overallLocalBest <= 0) return;
    void syncScoreToCloud(
      firebaseUser,
      overallLocalBest,
      progress.selectedDifficulty,
      runSummary?.distanceMeters ?? 0
    );
  }, [firebaseUser, overallLocalBest, progress.selectedDifficulty, runSummary?.distanceMeters, syncScoreToCloud]);

  const handleSendYuzuGift = useCallback(
    async (
      recipient: GlobalLeaderboardEntry,
      message: string
    ): Promise<{ ok: boolean; error?: string }> => {
      if (!firebaseUser) {
        return { ok: false, error: 'Hãy đăng nhập Google trước khi gửi quà.' };
      }
      if (recipient.uid === firebaseUser.uid) {
        return { ok: false, error: 'Bạn không thể tự gửi quà cho chính mình.' };
      }
      if (todaySentGift) {
        return {
          ok: false,
          error: `Hôm nay bạn đã gửi quà cho ${todaySentGift.recipientName} rồi.`,
        };
      }
      try {
        const sent = await sendYuzuGift({
          senderUser: firebaseUser,
          senderName: progress.appearance.name || firebaseUser.displayName || 'Capybara',
          recipientUid: recipient.uid,
          recipientName: recipient.playerName,
          message,
        });
        setTodaySentGift(sent);
        soundEngine.playGoldenYuzu();
        return { ok: true };
      } catch (err) {
        const msg = err instanceof Error ? err.message : '';
        if (msg.includes('permission') || msg.includes('PERMISSION_DENIED')) {
          return {
            ok: false,
            error: 'Bạn đã sử dụng lượt gửi Gói quà quýt hôm nay hoặc người nhận không hợp lệ.',
          };
        }
        return { ok: false, error: 'Không thể gửi gói quà lúc này. Vui lòng thử lại.' };
      }
    },
    [firebaseUser, progress.appearance.name, todaySentGift]
  );

  const handleClaimYuzuGift = useCallback(async (gift: YuzuGift) => {
    await claimYuzuGift(gift.id);
    soundEngine.playGoldenYuzu();
    setProgress((prev) => ({
      ...prev,
      yuzuBank: prev.yuzuBank + (gift.yuzuAmount || YUZU_GIFT_AMOUNT),
    }));
  }, []);

  const handleChangeName = useCallback((name: string) => {
    setProgress((prev) => ({
      ...prev,
      appearance: {
        ...prev.appearance,
        name,
      },
    }));
  }, []);

  const handleSelectOrUnlockFur = useCallback((furId: FurColorId) => {
    setProgress((prev) => {
      if (prev.unlockedFur.includes(furId)) {
        return {
          ...prev,
          appearance: { ...prev.appearance, fur: furId },
        };
      }
      const item = FUR_OPTIONS.find((f) => f.id === furId);
      if (!item || prev.yuzuBank < item.cost) return prev;
      soundEngine.playUnlock();
      return {
        ...prev,
        yuzuBank: prev.yuzuBank - item.cost,
        unlockedFur: [...prev.unlockedFur, furId],
        appearance: { ...prev.appearance, fur: furId },
      };
    });
  }, []);

  const handleSelectOrUnlockHead = useCallback((headId: HeadAccessoryId) => {
    setProgress((prev) => {
      if (prev.unlockedHead.includes(headId)) {
        return {
          ...prev,
          appearance: { ...prev.appearance, head: headId },
        };
      }
      const item = HEAD_ACCESSORIES.find((h) => h.id === headId);
      if (!item || prev.yuzuBank < item.cost) return prev;
      soundEngine.playUnlock();
      return {
        ...prev,
        yuzuBank: prev.yuzuBank - item.cost,
        unlockedHead: [...prev.unlockedHead, headId],
        appearance: { ...prev.appearance, head: headId },
      };
    });
  }, []);

  const handleSelectOrUnlockNeck = useCallback((neckId: NeckAccessoryId) => {
    setProgress((prev) => {
      if (prev.unlockedNeck.includes(neckId)) {
        return {
          ...prev,
          appearance: { ...prev.appearance, neck: neckId },
        };
      }
      const item = NECK_ACCESSORIES.find((n) => n.id === neckId);
      if (!item || prev.yuzuBank < item.cost) return prev;
      soundEngine.playUnlock();
      return {
        ...prev,
        yuzuBank: prev.yuzuBank - item.cost,
        unlockedNeck: [...prev.unlockedNeck, neckId],
        appearance: { ...prev.appearance, neck: neckId },
      };
    });
  }, []);

  const handleUnlockSkill = useCallback((skillId: SkillId) => {
    setProgress((prev) => {
      if (prev.unlockedSkills.includes(skillId)) return prev;
      const skill = BOSS_SKILLS.find((s) => s.id === skillId);
      if (!skill || prev.yuzuBank < skill.cost) return prev;
      soundEngine.playUnlock();
      return {
        ...prev,
        yuzuBank: prev.yuzuBank - skill.cost,
        unlockedSkills: [...prev.unlockedSkills, skillId],
      };
    });
  }, []);

  const handleSaveCustomMap = useCallback((map: CustomMap) => {
    setProgress((prev) => ({
      ...prev,
      customMaps: [map, ...prev.customMaps.filter((m) => m.id !== map.id)],
    }));
  }, []);

  const handleDeleteCustomMap = useCallback((mapId: string) => {
    setProgress((prev) => ({
      ...prev,
      customMaps: prev.customMaps.filter((m) => m.id !== mapId),
    }));
  }, []);

  const handleAddYuzu = useCallback((amount: number) => {
    setProgress((prev) => ({
      ...prev,
      yuzuBank: prev.yuzuBank + amount,
    }));
  }, []);

  const handleRandomizeOutfit = useCallback(() => {
    setProgress((prev) => {
      const pick = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
      soundEngine.playYuzu(3);
      return {
        ...prev,
        appearance: {
          ...prev.appearance,
          fur: pick(prev.unlockedFur),
          head: pick(prev.unlockedHead),
          neck: pick(prev.unlockedNeck),
        },
      };
    });
  }, []);

  const handleBuyFood = useCallback((foodId: FoodId) => {
    setProgress((prev) => {
      const food = FOOD_ITEMS.find((f) => f.id === foodId);
      if (!food || prev.yuzuBank < food.cost) return prev;
      soundEngine.playUnlock();
      return {
        ...prev,
        yuzuBank: prev.yuzuBank - food.cost,
        foodInventory: {
          ...prev.foodInventory,
          [foodId]: (prev.foodInventory[foodId] ?? 0) + 1,
        },
      };
    });
  }, []);

  const handleFeedCapybara = useCallback((foodId: FoodId) => {
    setProgress((prev) => {
      const count = prev.foodInventory[foodId] ?? 0;
      const food = FOOD_ITEMS.find((f) => f.id === foodId);
      if (!food || count <= 0) return prev;
      soundEngine.playPowerUp();
      return {
        ...prev,
        foodInventory: {
          ...prev.foodInventory,
          [foodId]: count - 1,
        },
        needs: {
          hunger: clampStat(prev.needs.hunger + food.hungerGain),
          energy: clampStat(prev.needs.energy + food.energyGain),
          happiness: clampStat(prev.needs.happiness + food.happinessGain),
          updatedAt: Date.now(),
        },
      };
    });
  }, []);

  const handleUnlockOrToggleHomeItem = useCallback((itemId: HomeItemId) => {
    setProgress((prev) => {
      if (prev.unlockedHomeItems.includes(itemId)) {
        const isPlaced = prev.activeHomeItems.includes(itemId);
        soundEngine.playYuzu(1);
        return {
          ...prev,
          activeHomeItems: isPlaced
            ? prev.activeHomeItems.filter((i) => i !== itemId)
            : [...prev.activeHomeItems, itemId],
        };
      }
      const item = HOME_ITEMS.find((h) => h.id === itemId);
      if (!item || prev.yuzuBank < item.cost) return prev;
      soundEngine.playUnlock();
      return {
        ...prev,
        yuzuBank: prev.yuzuBank - item.cost,
        unlockedHomeItems: [...prev.unlockedHomeItems, itemId],
        activeHomeItems: [...prev.activeHomeItems, itemId],
      };
    });
  }, []);

  const handleSelectOrUnlockPet = useCallback((petId: PetId) => {
    setProgress((prev) => {
      if (prev.unlockedPets.includes(petId)) {
        soundEngine.playYuzu(2);
        return {
          ...prev,
          selectedPet: petId,
        };
      }
      const pet = PET_OPTIONS.find((p) => p.id === petId);
      if (!pet || prev.yuzuBank < pet.cost) return prev;
      soundEngine.playUnlock();
      return {
        ...prev,
        yuzuBank: prev.yuzuBank - pet.cost,
        unlockedPets: [...prev.unlockedPets, petId],
        selectedPet: petId,
      };
    });
  }, []);

  const handleCarePet = useCallback(
    (petId: Exclude<PetId, 'none'>, action: 'pet' | 'treat'): { message: string; ok: boolean } => {
      if (action === 'treat' && progress.yuzuBank < 3) {
        return { ok: false, message: 'Cần 3 quýt để cho thú cưng ăn vặt.' };
      }
      const pet = PET_OPTIONS.find((p) => p.id === petId);
      const petName = pet?.name ?? 'Thú cưng';

      if (action === 'pet') {
        soundEngine.playYuzu(3);
        setProgress((prev) => ({
          ...prev,
          petBond: {
            ...prev.petBond,
            [petId]: clampStat((prev.petBond[petId] ?? 30) + 8),
          },
        }));
        return { ok: true, message: `Đã vuốt ve ${petName} (+8% Thân thiết)` };
      }

      soundEngine.playPowerUp();
      setProgress((prev) => ({
        ...prev,
        yuzuBank: Math.max(0, prev.yuzuBank - 3),
        petBond: {
          ...prev.petBond,
          [petId]: clampStat((prev.petBond[petId] ?? 30) + 18),
        },
      }));
      return { ok: true, message: `${petName} rất thích món ăn vặt (+18% Thân thiết)` };
    },
    [progress.yuzuBank]
  );

  const handleWorldActivity = useCallback(
    (
      kind:
        | 'rest'
        | 'swim'
        | 'toss_yuzu'
        | 'forage'
        | 'meditate'
        | 'bounce'
        | 'pet'
        | 'playground_hit'
        | 'capy_activity',
      payload?: { golden?: boolean; activityId?: CapybaraActivityId }
    ): { message: string; ok: boolean } => {
      if (kind === 'forage' && progress.needs.energy < 15) {
        return {
          ok: false,
          message: 'Capybara đang mệt! Hãy về Nhà riêng ngủ trưa hoặc ăn thêm thức ăn.',
        };
      }

      let resultMessage = '';

      if (kind === 'capy_activity' && payload?.activityId) {
        const meta = CAPYBARA_ACTIVITIES.find((a) => a.id === payload.activityId);
        if (!meta) return { ok: false, message: 'Không tìm thấy hoạt động.' };
        if (payload.activityId === 'selfie') {
          soundEngine.playCameraShutter();
        } else if (payload.activityId === 'bubble_bath' || payload.activityId === 'dive_swim') {
          soundEngine.playSplash();
        } else if (payload.activityId === 'nap_snore' || payload.activityId === 'sleep_teddy') {
          soundEngine.playSnore();
        } else if (payload.activityId === 'eat_watermelon') {
          soundEngine.playChew();
        } else if (payload.activityId === 'arcade_game') {
          soundEngine.playArcadeBeep();
        } else {
          soundEngine.playPowerUp();
        }
        const reward = meta.yuzuReward ?? 0;
        resultMessage =
          reward > 0
            ? `${meta.label} (+${meta.happinessDelta}% Vui, +${reward} Quýt)`
            : `${meta.label} (+${meta.happinessDelta}% Vui)`;
        setProgress((prev) => ({
          ...prev,
          yuzuBank: prev.yuzuBank + reward,
          needs: {
            hunger: clampStat(prev.needs.hunger + meta.hungerDelta),
            energy: clampStat(prev.needs.energy + meta.energyDelta),
            happiness: clampStat(prev.needs.happiness + meta.happinessDelta),
            updatedAt: Date.now(),
          },
        }));
        return { ok: true, message: resultMessage };
      }

      if (kind === 'rest') {
        const hasPlushBed = progress.activeHomeItems.includes('plush_bed');
        const gain = hasPlushBed ? 45 : 35;
        soundEngine.playSnore();
        resultMessage = `Ngủ trưa ngon giấc (+${gain}% Năng lượng)`;
        setProgress((prev) => ({
          ...prev,
          needs: {
            ...prev.needs,
            energy: clampStat(prev.needs.energy + gain),
            happiness: clampStat(prev.needs.happiness + 8),
            updatedAt: Date.now(),
          },
        }));
      } else if (kind === 'swim') {
        soundEngine.playSplash();
        resultMessage = 'Bơi suối mát lạnh (+22% Vui, +10% Năng lượng)';
        setProgress((prev) => ({
          ...prev,
          needs: {
            ...prev.needs,
            energy: clampStat(prev.needs.energy + 10),
            happiness: clampStat(prev.needs.happiness + 22),
            hunger: clampStat(prev.needs.hunger - 4),
            updatedAt: Date.now(),
          },
        }));
      } else if (kind === 'toss_yuzu') {
        const bonus = Math.random() < 0.55 ? 2 : 0;
        soundEngine.playYuzu(3);
        resultMessage =
          bonus > 0
            ? `Capybara vớt được +${bonus} Quýt từ hồ bơi! (+16% Vui)`
            : 'Capybara vờn quýt dưới nước rất thích thú (+16% Vui)';
        setProgress((prev) => ({
          ...prev,
          yuzuBank: prev.yuzuBank + bonus,
          needs: {
            ...prev.needs,
            happiness: clampStat(prev.needs.happiness + 16),
            updatedAt: Date.now(),
          },
        }));
      } else if (kind === 'forage') {
        const yuzuFound = 4 + Math.floor(Math.random() * 6);
        const foodPool: FoodId[] = ['carrot', 'yuzu_sweet', 'bamboo_salad'];
        const foundFood = Math.random() < 0.65 ? foodPool[Math.floor(Math.random() * foodPool.length)] : null;
        const foodName = foundFood
          ? FOOD_ITEMS.find((f) => f.id === foundFood)?.name
          : null;
        soundEngine.playGoldenYuzu();
        resultMessage = foodName
          ? `Hái được +${yuzuFound} Quýt & 1 ${foodName}!`
          : `Hái được +${yuzuFound} Quýt trong rừng tre!`;
        setProgress((prev) => ({
          ...prev,
          yuzuBank: prev.yuzuBank + yuzuFound,
          foodInventory: foundFood
            ? {
                ...prev.foodInventory,
                [foundFood]: (prev.foodInventory[foundFood] ?? 0) + 1,
              }
            : prev.foodInventory,
          needs: {
            ...prev.needs,
            energy: clampStat(prev.needs.energy - 15),
            hunger: clampStat(prev.needs.hunger - 6),
            happiness: clampStat(prev.needs.happiness + 10),
            updatedAt: Date.now(),
          },
        }));
      } else if (kind === 'meditate') {
        soundEngine.playPowerUp();
        resultMessage = 'Thiền dưới tán tre (+18% Năng lượng, +12% Vui)';
        setProgress((prev) => ({
          ...prev,
          needs: {
            ...prev.needs,
            energy: clampStat(prev.needs.energy + 18),
            happiness: clampStat(prev.needs.happiness + 12),
            updatedAt: Date.now(),
          },
        }));
      } else if (kind === 'bounce') {
        soundEngine.playJump(true);
        resultMessage = 'Nhảy bạt nhún cực đã (+20% Niềm vui)';
        setProgress((prev) => ({
          ...prev,
          needs: {
            ...prev.needs,
            energy: clampStat(prev.needs.energy - 5),
            happiness: clampStat(prev.needs.happiness + 20),
            updatedAt: Date.now(),
          },
        }));
      } else if (kind === 'pet') {
        resultMessage = 'Capybara thích thú khi được vuốt ve (+6% Niềm vui)';
        setProgress((prev) => ({
          ...prev,
          needs: {
            ...prev.needs,
            happiness: clampStat(prev.needs.happiness + 6),
            updatedAt: Date.now(),
          },
        }));
      } else if (kind === 'playground_hit') {
        const gain = payload?.golden ? 3 : 1;
        resultMessage = `Bắt trúng quýt (+${gain} Quýt, +3% Vui)`;
        setProgress((prev) => ({
          ...prev,
          yuzuBank: prev.yuzuBank + gain,
          needs: {
            ...prev.needs,
            happiness: clampStat(prev.needs.happiness + 3),
            updatedAt: Date.now(),
          },
        }));
      }

      return { ok: true, message: resultMessage };
    },
    [progress.activeHomeItems, progress.needs.energy]
  );

  const handleClaimQuest = useCallback((questId: string) => {
    setProgress((prev) => {
      const currentQuests = ensureCurrentDailyQuests(prev.dailyQuests);
      const targetQuest = currentQuests.quests.find((q) => q.id === questId);
      if (!targetQuest || targetQuest.claimed || targetQuest.progress < targetQuest.target) {
        return prev;
      }
      soundEngine.playPowerUp();
      return {
        ...prev,
        yuzuBank: prev.yuzuBank + targetQuest.rewardYuzu,
        dailyQuests: {
          ...currentQuests,
          quests: currentQuests.quests.map((q) =>
            q.id === questId ? { ...q, claimed: true } : q
          ),
        },
      };
    });
  }, []);

  const handleClaimAchievement = useCallback((achievementId: string) => {
    setProgress((prev) => {
      if (prev.claimedAchievements.includes(achievementId)) return prev;
      const def = ACHIEVEMENTS.find((a) => a.id === achievementId);
      if (!def || !isAchievementUnlocked(def, prev.achievementStats, prev.unlockedPets)) {
        return prev;
      }
      soundEngine.playGoldenYuzu();
      return {
        ...prev,
        yuzuBank: prev.yuzuBank + def.rewardYuzu,
        claimedAchievements: [...prev.claimedAchievements, achievementId],
      };
    });
  }, []);

  const currentDailyQuests = ensureCurrentDailyQuests(progress.dailyQuests);
  const wellFedBuff = hasWellFedBuff(progress.needs);
  const activePetBond =
    progress.selectedPet !== 'none' ? progress.petBond[progress.selectedPet] ?? 30 : 0;

  return (
    <div className="min-h-screen bg-[#111A16] text-[#F3F6F4]">
      <main className="mx-auto max-w-[1160px] px-4 py-6 sm:px-8 sm:py-8">
        {playMode === 'multiplayer' ? (
          <MultiplayerView
            appearance={progress.appearance}
            weatherMode={progress.weatherMode}
            customMaps={progress.customMaps}
            initialRoomCode={initialRoomCode}
            onSaveCustomMap={handleSaveCustomMap}
            onDeleteCustomMap={handleDeleteCustomMap}
            onAddYuzu={handleAddYuzu}
            onExitMultiplayer={handleExitMultiplayer}
          />
        ) : (
          <div className="overflow-hidden rounded-2xl border border-white/10 bg-[#16231D] shadow-2xl">
            {!photoMode && (
              <GameHud
                gameState={gameState}
                hud={{
                  ...hud,
                  highScore: Math.max(currentHighScore, hud.highScore),
                  yuzuBank: progress.yuzuBank,
                  stageName: stageConfig.name,
                }}
                capybaraName={progress.appearance.name}
                petId={progress.selectedPet}
                weatherMode={progress.weatherMode}
                muted={progress.muted}
                onCycleWeather={handleCycleWeather}
                onToggleMute={handleToggleMute}
                onTogglePause={handleTogglePause}
                onOpenPhotoMode={handleOpenPhotoMode}
              />
            )}

            <div className="relative">
              <GameCanvas
                gameState={gameState}
                playMode={playMode}
                difficulty={progress.selectedDifficulty}
                appearance={progress.appearance}
                weatherMode={progress.weatherMode}
                unlockedSkills={progress.unlockedSkills}
                wellFedBuff={wellFedBuff}
                petId={progress.selectedPet}
                petBond={activePetBond}
                stageConfig={stageConfig}
                photoMode={photoMode}
                photoPose={photoPose}
                captureApiRef={captureApiRef}
                highScore={currentHighScore}
                yuzuBank={progress.yuzuBank}
                runKey={runKey}
                onHudUpdate={setHud}
                onBossActiveChange={setBossActive}
                onGameOver={handleGameOver}
                onTogglePause={handleTogglePause}
              />

              {photoFlash && (
                <div
                  className="pointer-events-none absolute inset-0 bg-white/70 transition-opacity duration-200"
                  aria-hidden="true"
                />
              )}

              {!photoMode && gameState === 'TITLE_MENU' && (
                <TitleOverlay
                  difficulty={progress.selectedDifficulty}
                  weatherMode={progress.weatherMode}
                  highScore={currentHighScore}
                  onSelectDifficulty={handleSelectDifficulty}
                  onSelectWeather={handleSelectWeather}
                  onStartEndless={handleStartEndless}
                  onStartBossRush={handleStartBossRush}
                  onOpenMultiplayer={handleOpenMultiplayer}
                />
              )}

              {!photoMode && gameState === 'PAUSED' && (
                <PauseOverlay
                  onResume={handleTogglePause}
                  onRestart={playMode === 'boss_rush' ? handleStartBossRush : handleStartEndless}
                  onOpenPhotoMode={handleOpenPhotoMode}
                  onBackToMenu={handleBackToMenu}
                />
              )}

              {!photoMode && gameState === 'GAME_OVER' && runSummary && (
                <GameOverOverlay
                  summary={runSummary}
                  user={firebaseUser}
                  cloudStatus={cloudStatus}
                  cloudBestScore={personalCloudEntry?.score ?? null}
                  authBusy={authBusy}
                  onSignInAndSave={() =>
                    void handleSignIn({
                      score: runSummary.score,
                      distanceMeters: runSummary.distanceMeters,
                    })
                  }
                  onPlayAgain={playMode === 'boss_rush' ? handleStartBossRush : handleStartEndless}
                  onBackToMenu={handleBackToMenu}
                />
              )}
            </div>

            {photoMode ? (
              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-amber-400/25 bg-[#14201A] px-5 py-3">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-300">
                    <Camera className="h-4 w-4" aria-hidden="true" />
                    <span>Photo Mode (Đã ẩn HUD)</span>
                  </span>
                  <span className="text-white/20" aria-hidden="true">·</span>
                  <div className="flex flex-wrap items-center gap-1">
                    {(
                      [
                        { id: 'happy', label: 'Vui vẻ' },
                        { id: 'normal', label: 'Tự nhiên' },
                        { id: 'zen', label: 'Ngâm suối' },
                        { id: 'cool', label: 'Ngầu' },
                      ] as const
                    ).map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => setPhotoPose(p.id)}
                        className={`h-8 whitespace-nowrap rounded-md px-2.5 text-xs font-semibold transition-colors ${
                          photoPose === p.id
                            ? 'bg-amber-500 text-[#1A1308]'
                            : 'border border-white/10 bg-[#1D2E26] text-emerald-100 hover:bg-[#273E33]'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>

                  <button
                    type="button"
                    onClick={handleCycleWeather}
                    className="inline-flex h-8 items-center gap-1.5 whitespace-nowrap rounded-md border border-white/12 bg-[#1D2E26] px-2.5 text-xs font-medium text-emerald-100 hover:bg-[#273E33]"
                  >
                    <CloudRain className="h-3.5 w-3.5 text-sky-300" aria-hidden="true" />
                    <span>{getWeatherLabel(hud.activeWeather)}</span>
                  </button>

                  <label className="inline-flex h-8 cursor-pointer items-center gap-1.5 px-1.5 text-xs text-emerald-100/85">
                    <input
                      type="checkbox"
                      checked={photoWithSignature}
                      onChange={(e) => setPhotoWithSignature(e.target.checked)}
                      className="h-3.5 w-3.5 accent-amber-400"
                    />
                    <span>Ghi tên & màn</span>
                  </label>
                </div>

                <div className="flex items-center gap-2">
                  {photoSavedNotice && (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-300">
                      <Check className="h-3.5 w-3.5" aria-hidden="true" />
                      <span>Đã tải ảnh PNG!</span>
                    </span>
                  )}

                  <button
                    type="button"
                    onClick={handleCapturePhoto}
                    className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-lg bg-amber-500 px-4 text-xs font-bold text-[#1A1308] hover:bg-amber-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-300"
                  >
                    <Download className="h-4 w-4" aria-hidden="true" />
                    <span>Chụp & Tải ảnh</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleExitPhotoMode}
                    className="inline-flex h-10 items-center gap-1.5 whitespace-nowrap rounded-lg border border-white/15 bg-[#21332A] px-3.5 text-xs font-semibold text-white hover:bg-[#2B4337] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
                  >
                    <X className="h-4 w-4" aria-hidden="true" />
                    <span>Thoát (Esc)</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/10 bg-[#14201A] px-5 py-2.5 text-xs text-emerald-200/75">
                <div>
                  <span>Điều khiển: </span>
                  <span className="font-medium text-emerald-100">Space / W / L / ↑</span>
                  <span> nhảy đôi</span>
                  <span className="mx-2 text-white/25" aria-hidden="true">·</span>
                  <span className="font-medium text-emerald-100">A / D / ← / →</span>
                  <span> di chuyển khi đấu Boss</span>
                  <span className="mx-2 text-white/25" aria-hidden="true">·</span>
                  <span className="font-medium text-emerald-100">J / K / I / U</span>
                  <span> dùng kỹ năng</span>
                </div>
                <div className="font-mono-num text-emerald-200/80">
                  Màn: {stageConfig.name} · Chu kỳ Ngày/Đêm: 5 phút
                </div>
              </div>
            )}
          </div>
        )}

        {/* Global Leaderboard Top 10 */}
        <LeaderboardPanel
          entries={leaderboardEntries}
          loading={leaderboardLoading}
          errorMessage={leaderboardError}
          user={firebaseUser}
          personalEntry={personalCloudEntry}
          localBestScore={overallLocalBest}
          submitting={cloudStatus === 'saving'}
          authBusy={authBusy}
          todaySentGift={todaySentGift}
          incomingGifts={incomingGifts}
          onSignIn={() =>
            void handleSignIn(
              overallLocalBest > 0
                ? { score: overallLocalBest, distanceMeters: runSummary?.distanceMeters ?? 0 }
                : undefined
            )
          }
          onSignOut={() => void handleSignOut()}
          onSyncLocalBest={handleSyncLocalBest}
          onSendYuzuGift={handleSendYuzuGift}
          onClaimYuzuGift={handleClaimYuzuGift}
        />

        {/* Below: Capybara World Hub (Home, Pool, Forest, Shop, Playground, Wardrobe, Food, Pets) + Daily Quests */}
        <div className="mt-6 grid grid-cols-1 items-start gap-6 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <CapybaraWorldHub
              yuzuBank={progress.yuzuBank}
              appearance={progress.appearance}
              needs={progress.needs}
              foodInventory={progress.foodInventory}
              unlockedFur={progress.unlockedFur}
              unlockedHead={progress.unlockedHead}
              unlockedNeck={progress.unlockedNeck}
              unlockedSkills={progress.unlockedSkills}
              unlockedHomeItems={progress.unlockedHomeItems}
              activeHomeItems={progress.activeHomeItems}
              unlockedPets={progress.unlockedPets}
              selectedPet={progress.selectedPet}
              petBond={progress.petBond}
              achievementStats={progress.achievementStats}
              claimedAchievements={progress.claimedAchievements}
              activeWeather={hud.activeWeather}
              onChangeName={handleChangeName}
              onSelectOrUnlockFur={handleSelectOrUnlockFur}
              onSelectOrUnlockHead={handleSelectOrUnlockHead}
              onSelectOrUnlockNeck={handleSelectOrUnlockNeck}
              onRandomizeOutfit={handleRandomizeOutfit}
              onUnlockSkill={handleUnlockSkill}
              onBuyFood={handleBuyFood}
              onFeedCapybara={handleFeedCapybara}
              onUnlockOrToggleHomeItem={handleUnlockOrToggleHomeItem}
              onSelectOrUnlockPet={handleSelectOrUnlockPet}
              onCarePet={handleCarePet}
              onClaimAchievement={handleClaimAchievement}
              onOpenPhotoMode={handleOpenPhotoMode}
              onWorldActivity={handleWorldActivity}
            />
          </div>

          <div className="lg:col-span-4">
            <DailyQuestsPanel
              questState={currentDailyQuests}
              onClaimQuest={handleClaimQuest}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
