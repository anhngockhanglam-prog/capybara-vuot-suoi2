# Xuất bản Capybara Vượt Suối miễn phí bằng GitHub Pages

## 1. Tạo repository GitHub
1. Đăng nhập GitHub và tạo repository mới, ví dụ `capybara-vuot-suoi`.
2. Chọn **Public**.
3. Tải toàn bộ nội dung thư mục này lên repository (không tải file ZIP lồng bên trong).
4. Đảm bảo file `package.json`, `bun.lock`, `index.html` nằm ngay ở thư mục gốc repository.

## 2. Bật GitHub Pages
1. Mở tab **Settings → Pages** của repository.
2. Trong **Build and deployment**, chọn **Source: GitHub Actions**.
3. Mở tab **Actions**, chờ workflow **Deploy Capybara game to GitHub Pages** chạy xong màu xanh.
4. Đường link sẽ có dạng `https://TEN-GITHUB.github.io/capybara-vuot-suoi/`.

## Lưu ý về tính năng
- Bản GitHub Pages là website tĩnh. Chế độ chơi đơn và lưu tiến trình trên trình duyệt có thể hoạt động.
- Dự án có server WebSocket riêng (`server.ts`) cho phòng chơi nhiều người. GitHub Pages không chạy server này, nên multiplayer/phòng trực tuyến sẽ không hoạt động nếu chưa triển khai backend riêng.
- Đăng nhập Google, bảng xếp hạng và dữ liệu Firebase còn phụ thuộc cấu hình Firebase, quy tắc Firestore và việc thêm domain GitHub Pages vào Firebase Authentication → Authorized domains.
- Không đưa khóa bí mật hoặc mật khẩu vào repository công khai. Firebase Web API key trong ứng dụng web thường là cấu hình nhận diện dự án, nhưng cần bảo vệ dữ liệu bằng Firebase Security Rules và giới hạn API phù hợp.
